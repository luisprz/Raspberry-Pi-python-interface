#!/bin/sh
cd app
xinit /usr/bin/python3 lcars.py
