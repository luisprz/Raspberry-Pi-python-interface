#!/usr/bin/env python
# -*- coding: utf-8 -*-

from numpy import array
from numpy import *
import sys, traceback
import MySQLdb as ndb
import random
import serial
import sys
import json
from pprint import pprint
import copy
import os, time
import signal
import requests
import serial
import RPi.GPIO as GPIO  

from datetime import datetime
import pygame
from pygame.mixer import Sound
import subprocess

from ui import colours
from ui.widgets.background import LcarsBackgroundImage, LcarsImage
from ui.widgets.gifimage import LcarsGifImage
from ui.widgets.lcars_widgets import *
from ui.widgets.screen import LcarsScreen
from ui.widgets.sprite import LcarsMoveToMouse

#from datasources.network import get_ip_address_string

'''
class ScreenOption(LcarsScreen):
    def setup(self, all_sprites):
        print "Hello, world!"

if __name__ == '__main__':
    Example().setup()
'''


class ScreenOption(LcarsScreen):

    def setup(self, all_sprites):
        
        all_sprites.add(LcarsBackgroundImage("assets/blackbackground.png"),
                        layer=0)
        
        # panel text
        '''
        all_sprites.add(LcarsText(colours.BLACK, (15, 44), "LCARS 105"),
                        layer=1)
        '''
        all_sprites.add(LcarsText(colours.BLUE, (23, 119), "Select An Option", 3),
                        layer=1)
        '''
        all_sprites.add(LcarsBlockMedium(colours.RED_BROWN, (145, 16), "LIGHTS"),
                        layer=1)
        all_sprites.add(LcarsBlockSmall(colours.ORANGE, (211, 16), "CAMERAS"),
                        layer=1)
        all_sprites.add(LcarsBlockLarge(colours.BEIGE, (249, 16), "ENERGY"),
                        layer=1)

        self.ip_address = LcarsText(colours.BLACK, (444, 520),
                                    get_ip_address_string())
        all_sprites.add(self.ip_address, layer=1)
        '''

        '''
        # info text
        all_sprites.add(LcarsText(colours.WHITE, (192, 174), "EVENT LOG:", 1.5),
                        layer=3)
        all_sprites.add(LcarsText(colours.BLUE, (244, 174), "2 ALARM ZONES TRIGGERED", 1.5),
                        layer=3)
        all_sprites.add(LcarsText(colours.BLUE, (286, 174), "14.3 kWh USED YESTERDAY", 1.5),
                        layer=3)
        all_sprites.add(LcarsText(colours.BLUE, (330, 174), "1.3 Tb DATA USED THIS MONTH", 1.5),
                        layer=3)
        self.info_text = all_sprites.get_sprites_from_layer(3)

        '''

        # date display
        self.stardate = LcarsText(colours.BLUE, (178, 147), "DATE 27.11.05 12:02:32", 1.5)
        self.lastClockUpdate = 0
        all_sprites.add(self.stardate, layer=1)

        
        self.tverified = LcarsText(colours.BLUE, (215, 208), "", 1.5)
        all_sprites.add(self.tverified, layer=1)
        
        
        # buttons
        all_sprites.add(LcarsButton(colours.RED_BROWN, (250, 54), "LOGOUT       ", self.logoutHandler),
                        layer=4)

        all_sprites.add(LcarsButton(colours.RED_BROWN, (250, 193), "GPRS ON       ", self.GPRSon),
                        layer=4)
        all_sprites.add(LcarsButton(colours.RED_BROWN, (250, 332), "GPRS OFF       ", self.GPRSoff),
                        layer=4)       
        
        all_sprites.add(LcarsButton(colours.BEIGE, (102, 274), "LABORATORY   ", self.labHandler),
                        layer=4)
        

        
        all_sprites.add(LcarsButton(colours.BEIGE, (102, 100), "PHARMACY    ", self.pharmHandler),
                        layer=4)
        

        '''
        
        all_sprites.add(LcarsButton(colours.PURPLE, (59, 197), "Upload", self.gaugesHandler),
                        layer=4)
        
        all_sprites.add(LcarsButton(colours.PEACH, (107, 398), "WEATHER", self.weatherHandler),
                        layer=4)

        '''

        # gadgets
        #all_sprites.add(LcarsGifImage("assets/gadgets/fwscan.gif", (277, 556), 100), layer=1)
        #self.sensor_gadget = subprocess.Popen("assets/gadgets/scan_uhf.py")
        #self.sensor_gadget = exec(open('python assets/gadgets/scan_uhf.py').read())
        #self.sensor_gadget = os.system("python <path to .py file>")
        #self.sensor_gadget = python assets/gadgets/scan_uhf.py, (235, 150), 100
        #self.sensor_gadget = LcarsGifImage("assets/gadgets/lcars_anim2.gif", (235, 150), 100)
        #self.sensor_gadget.visible = False
        #all_sprites.add(self.sensor_gadget, layer=2)

        '''
        self.dashboard = LcarsImage("assets/gadgets/dashboard.png", (187, 232))
        self.dashboard.visible = False
        all_sprites.add(self.dashboard, layer=2)

        self.weather = LcarsImage("assets/weather.jpg", (188, 122))
        self.weather.visible = False
        all_sprites.add(self.weather, layer=2)
        '''

        #all_sprites.add(LcarsMoveToMouse(colours.WHITE), layer=1)
        self.beep1 = Sound("assets/audio/panel/201.wav")
        Sound("assets/audio/panel/220.wav").play()

    def update(self, screenSurface, fpsClock):
        if pygame.time.get_ticks() - self.lastClockUpdate > 1000:
            self.stardate.setText("DATE {}".format(datetime.now().strftime("%d.%m.%y %H:%M:%S")))
            self.lastClockUpdate = pygame.time.get_ticks()
        LcarsScreen.update(self, screenSurface, fpsClock)

    def handleEvents(self, event, fpsClock):
        if event.type == pygame.MOUSEBUTTONDOWN:
            self.beep1.play()

        if event.type == pygame.MOUSEBUTTONUP:
            return False
    

    def hideInfoText(self):
        if self.info_text[0].visible:
            for sprite in self.info_text:
                sprite.visible = False


    def labHandler(self, item, event, clock): #laboratorio
        from screens.screenlab import ScreenLab
        self.loadScreen(ScreenLab())

    def pharmHandler(self, item, event, clock): #farmacia
        from screens.screenpharm import ScreenPharm
        self.loadScreen(ScreenPharm())

    
    '''
    
    def gaugesHandler(self, item, event, clock): #
        self.hideInfoText()
        self.sensor_gadget.visible = False
        self.dashboard.visible = True
        self.weather.visible = False





    def UpAll(self, item, event, clock): #subir todo a la nube desde la bd local
                ##################################### Escanear Serial ###############################
        def getserial():
          # Extract serial from cpuinfo file
          cpuserial = "0000000000000000"
          try:
            f = open('/proc/cpuinfo','r')
            for line in f:
              if line[0:6]=='Serial':
                cpuserial = line[10:26]
            f.close()
          except:
            cpuserial = "ERROR000000000"

          return cpuserial


        ######################################### Subir a la nube con el WIFI ################################
                
        def send_simple_tag_to_api(url,id_tag_nfc,id_tag_uhf,tag_id_department):
            try:
                #simplemente agregar aqui, el key y el value. y lo pasas por la funcion. ya el api se encarga del resto. 
                payload = {'tag_id_department':tag_id_department,'id_tag_uhf':id_tag_uhf,'id_tag_nfc':id_tag_nfc,'serial_number':getserial()}
                resp = requests.get(url,params=payload)
                print(resp.url)
                if resp.status_code==200:
                    data=resp.json()
                    success = str(data["success"])
                    if success=="1":
                        return 1
                    if success=="2":
                        print "Ya esta en la nube"
                        return 2
                    if success=="0":
                        print data
                        return 0
                else:
                    print ("Error while sending to API. Check url or API.")
                    return -1
            except:
                print ("General Error while sending to API")
                return -1
                
                
        ######################################### Subir a la nube con el GPRS ################################      
                
        def send_cloud_GRPS(url):
            
            GPIO.setmode(GPIO.BOARD)
            # Enable Serial Communication
            port = serial.Serial("/dev/ttyUSB1", baudrate=115200, timeout=5)

            port.write('AT'+'\r\n') 
            rcv = port.read(10)
            time.sleep(1)

            port.write('AT+CSQ'+'\r\n') #Signal quality report
            rcv = port.read(10)
            time.sleep(1)

            port.write('AT+CGATT=1'+'\r\n') #Attach from GPRS service
            rcv = port.read(10)
            time.sleep(1)
            print "1"
            port.write('AT+SAPBR=3,1,"CONTYPE","GPRS"'+'\r\n') #Bearer setting for application based on ip, Type of internet conection ->GPRS
            rcv = port.read(10)
            time.sleep(1)

            port.write('AT+SAPBR=3,1,"APN","internet.ideasclaro.com.do"'+'\r\n') #Name of APN
            rcv = port.read(10)
            time.sleep(1)
            print "2"
            port.write('AT+SAPBR=1,1'+'\r\n') #Open bearer, bearer is conected 
            rcv = port.read(10)
            time.sleep(1)

            port.write('AT+HTTPINIT'+'\r\n') #Initialize HTTP service
            rcv = port.read(10)
            time.sleep(1)

            port.write('AT+HTTPPARA="URL","'+url+'"'+'\r\n') #Set HTTP parameters Value
            rcv = port.read(10)
            time.sleep(1)
            print "3"
            port.write('AT+HTTPACTION=0'+'\r\n')  #HTTP method action, method ->GET 
            rcv = port.read(10)
            
            time.sleep(3)

            port.write('AT+HTTPREAD'+'\r\n')  #Read HTTP server response 
            rcv = port.read(10)
            time.sleep(1)

            port.write('AT+HTTPTERM'+'\r\n') #Terminate HTTP service
            rcv = port.read(1000)
            

            if '"success":"1"' in rcv: 
                print "Registro EXITOSO"
                print rcv
                return 1
            elif '"success":"2"' in rcv: 
                print "Existe en la BD"
                print rcv
                return 2    
            elif '"success":"0"' in rcv: 
                print "Registro NO EXITOSO"
                print rcv
                return 0
            else:
                print "Error en el GRPS"
                print rcv
                return -1
                
        def update_tag(id_tag_nfc,id_tag_uhf):
            

            try:
                sql="UPDATE tags set cloud=1,date_uploaded=now() where id_tag_nfc='%s'"%(id_tag_nfc)
                sql2="UPDATE tags set cloud=1,date_uploaded=now() where id_tag_uhf='%s'"%(id_tag_uhf)
                if str(id_tag_nfc)!="":
                    cursor.execute(sql)
                if str(id_tag_uhf)!="":
                    cursor.execute(sql2)
                
                con.commit()
                print "Tag Uploaded: " +str(id_tag_uhf)
                print "Tag Uploaded: " +str(id_tag_nfc)
            except:
                print "Tag subido a la nube pero no a la BD local."
            
        ######################################### MAIN PROGRAM ################################
        con= ndb.connect ('localhost','root','password','vp')
        cursor= con.cursor()
        tag_id_department=1 #department por default
        url="http://54.183.201.48/api/tags_save"

        sql="SELECT `id_tag_nfc`,`id_tag_uhf` FROM `tags` where cloud=0 limit 1"

        cursor.execute(sql)
        valores = cursor.fetchall()

        for row in valores:
            id_tag_uhf = row[1]
            id_tag_nfc = row[0]

            var=send_simple_tag_to_api(url,id_tag_nfc,id_tag_uhf,tag_id_department)
            #var=send_simple_tag_nfc_to_api(url,id_tag_nfc,tag_id_department)
            #aqui estas asisgnando dos valores a una variable. por lo tanto la variable tendra el ultimo valor asignado
            #este es el error que tienes. pero puedes subir los dos tags, por la misma funcion. 
            if var==1 or var ==2:
                #update_tag(id_tag_nfc)
                update_tag(id_tag_nfc,id_tag_uhf)
            
            if var==0:
                print "Datos en la nube"
                
            if var==-1:
                print "Error de conexion, intentando GPRS"
                url=url+ "?tag_id_department=" +str(tag_id_department)+"&id_tag_nfc="+str(id_tag_nfc)+"&id_tag_uhf="+str(id_tag_uhf)+"&serial_number="+str(getserial())

                print url
                var_gprs=send_cloud_GRPS(url)
                if var_gprs==1 or var_gprs==2:
                    update_tag(id_tag_uhf,id_tag_uhf)
                    

                if var_gprs==0:
                    print "Datos en la nube"
                if var_gprs==-1:
                    print "Error de conexion. Reintentar mas tarde"

        print "FIN."
        cursor.close()#Logout Servidor
        ##Hasta aqui verify.




    def sensorsHandler(self, item, event, clock): #Upload
        
        #########################################Subir a la bd local################################

        def send_db_local(id_tag_uhf):
                try:
                    
                    
                    #sql="INSERT INTO tags (`id_tag_uhf`,date_created,cloud,date_uploaded) VALUES (123213213213213123155588,now(),0,now())"

                    sql="INSERT INTO tags (`id_tag_uhf`,date_created,cloud,date_uploaded) VALUES (%s,now(),0,now());"
                    args=(id_tag_uhf)
                    
                    cursor.execute(sql,args)
                    con.commit()
                    #print "llego aqui."
                    return 1
                except:
                    return 0
                    #print "soy yo?"
                
                
                
        ######################################### FILTRAR EPC ################################

        def real_tag_epc(tag):
            string1=tag[14:]
            finalstring =string1[:-6]
            return finalstring

        def getserial():
          # Extract serial from cpuinfo file
          cpuserial = "0000000000000000"
          try:
            f = open('/proc/cpuinfo','r')
            for line in f:
              if line[0:6]=='Serial':
                cpuserial = line[10:26]
            f.close()
          except:
            cpuserial = "ERROR000000000"

          return cpuserial


        ser = serial.Serial(

            port = '/dev/serial/by-path/platform-3f980000.usb-usb-0:1.2:1.0-port0',
            #port = '/dev/ttyUSB0',
            baudrate = 57600, 
            parity = serial.PARITY_NONE,
            stopbits = serial.STOPBITS_ONE,
            bytesize = serial.EIGHTBITS, 
            timeout = 1 
            )  
        con= ndb.connect ('localhost','root','password','vp')
        cursor= con.cursor() 



        #print("serial: ", getserial())
        #print('port open is: ', ser.name)         # check which port was really used
        tagHex = ""
        ser.write('\x06\xFF\x01\x01\x00\xC6\x8D')     # write a string
        #print(cmdLeer)
        time.sleep(1)
        bytesCola = ser.inWaiting()
        #getserial()
        #print ("serial pi: "+ getserial())
        if bytesCola > 0:
            tagHex = ser.readline(bytesCola).encode('Hex')
            arr = []
            for i in tagHex:
                arr.append(i)
    
            fulltag = ''.join(arr)
            real_tag=real_tag_epc(fulltag)
            #print "Tag_UHF: "+real_tag
        
        id_tag_uhf=real_tag


            
        while 1:
            try:
                #print("serial: ", getserial())
                #print('port open is: ', ser.name)         # check which port was really used
                tagHex = ""
                ser.write('\x06\xFF\x01\x01\x00\xC6\x8D')     # write a string
                #print(cmdLeer)
                time.sleep(1)
                bytesCola = ser.inWaiting()
                #getserial()
                #print ("serial pi: "+ getserial())
                if bytesCola > 0:
                    tagHex = ser.readline(bytesCola).encode('Hex')
                    arr = []
                    for i in tagHex:
                        arr.append(i)
            
                    fulltag = ''.join(arr)
                    real_tag=real_tag_epc(fulltag)
                    #print "Tag_UHF: "+real_tag
                
                id_tag_uhf=real_tag
                if tagHex != '0700010101001e4b' and tagHex != '':
                    
                    if len(id_tag_uhf) % 24==0:
                        
                        #print ("Lo que se supone a subir: ", id_tag_uhf)
                        bien=send_db_local(id_tag_uhf)
                        if bien==1:
                            print "Tag Subido: ", id_tag_uhf
                        else:
                            print "No se subio correctamente o tag repetido: ", id_tag_uhf
                            
                        
                else:
                    print("No se encontro ningun tag, codigo no lectura: ",tagHex)
                    
            except:
                print "se jodio la mielda."
                cursor.close()#Logout Servidor
                sys.exit(0)
         
        cursor.close() #Logout Servidor




            #from screens.verification import verify
            #self.hideInfoText()
            #self.subprocess.Popen("python <assets/gadgets/scan_uhf.py >")
            #self.sensor_gadget.visible = True
            #self.dashboard.visible = False
            #self.weather.visible = False

    '''

    def GPRSon(self, item, event, clock):

        port = serial.Serial("/dev/serial/by-path/platform-3f980000.usb-usb-0:1.5:1.0-port0", baudrate=115200, timeout=5)

        port.write('AT'+'\r\n') 
        rcv = port.read(10)
        time.sleep(1)

        if "OK" in rcv: 
            print "GPRS esta encendido."
            self.tverified.setText("GPRS IS ON")

            
        else:
        
        	
	        GPIO.setmode(GPIO.BCM)
	        #GPIO.setup(12, GPIO.OUT)
	        GPIO.setup(12, GPIO.OUT, initial=GPIO.LOW)

	        GPIO.output(12, False)
	        time.sleep(1)
	        GPIO.output(12, True)
	        time.sleep(2)
	        GPIO.output(12, False)
	        time.sleep(3)
	        GPIO.cleanup() #this ensures a clean exit
	        
	        self.tverified.setText("GPRS IS ON")

    def GPRSoff(self, item, event, clock):

        port = serial.Serial("/dev/serial/by-path/platform-3f980000.usb-usb-0:1.5:1.0-port0", baudrate=115200, timeout=5)

        port.write('AT'+'\r\n') 
        rcv = port.read(10)
        time.sleep(1)

        
        if "OK" in rcv: 
            
	        GPIO.setmode(GPIO.BCM)
	        #GPIO.setup(12, GPIO.OUT)
	        GPIO.setup(12, GPIO.OUT, initial=GPIO.LOW)

	        GPIO.output(12, False)
	        time.sleep(1)
	        GPIO.output(12, True)
	        time.sleep(2)
	        GPIO.output(12, False)
	        time.sleep(3)
	        GPIO.cleanup() #this ensures a clean exit
	        self.tverified.setText("GPRS IS OFF")
		        


    def logoutHandler(self, item, event, clock):
        from screens.authorize import ScreenAuthorize
        self.loadScreen(ScreenAuthorize())

    

'''

if __name__ == '__main__':
	
	GPIO.setmode(GPIO.BCM)
	ScreenOption().setup()
'''
