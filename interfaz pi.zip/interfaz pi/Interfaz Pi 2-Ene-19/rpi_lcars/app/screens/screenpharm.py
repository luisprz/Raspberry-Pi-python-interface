#!/usr/bin/env python
# -*- coding: utf-8 -*-

from numpy import array
from numpy import *
import sys, traceback
import MySQLdb as ndb
import random
import serial
import sys
import json
from pprint import pprint
import copy
import os, time
import signal
import requests
import serial
import RPi.GPIO as GPIO  
from urllib2 import urlopen
import urllib 
import nfc


from datetime import datetime
import pygame
from pygame.mixer import Sound
import subprocess

from ui import colours
from ui.widgets.background import LcarsBackgroundImage, LcarsImage
from ui.widgets.gifimage import LcarsGifImage
from ui.widgets.lcars_widgets import *
from ui.widgets.screen import LcarsScreen
from ui.widgets.sprite import LcarsMoveToMouse

#from datasources.network import get_ip_address_string
#signal.signal(signal.SIGINT, signal_handler)

tag_id_department=1 #department por default


class ScreenPharm(LcarsScreen):
    def setup(self, all_sprites):
        
        all_sprites.add(LcarsBackgroundImage("assets/blackbackground.png"),
                        layer=0)


        # panel text
        '''
        all_sprites.add(LcarsText(colours.WHITE, (15, 44), "LCARS 105"),
                        layer=1)
        
        all_sprites.add(LcarsText(colours.ORANGE, (16, 145), "VeriPro", 2),
                        layer=1)
        '''
        all_sprites.add(LcarsText(colours.BLUE, (120, 42), "Pharmacy by VP System", 3),
                        layer=1)
        

        
        

        '''
        all_sprites.add(LcarsBlockLarge(colours.WHITE, (103, 334), "KLK"),
                        layer=1)
        '''
        

        '''
        self.ip_address = LcarsText(colours.BLACK, (444, 520), get_ip_address_string())
        all_sprites.add(self.ip_address, layer=1)
        '''
        

        '''
        # info text
        all_sprites.add(LcarsText(colours.WHITE, (192, 174), "EVENT LOG:", 1.5),
                        layer=3)
        all_sprites.add(LcarsText(colours.BLUE, (244, 174), "2 ALARM ZONES TRIGGERED", 1.5),
                        layer=3)
        all_sprites.add(LcarsText(colours.BLUE, (286, 174), "14.3 kWh USED YESTERDAY", 1.5),
                        layer=3)
        all_sprites.add(LcarsText(colours.BLUE, (330, 174), "1.3 Tb DATA USED THIS MONTH", 1.5),
                        layer=3)
        self.info_text = all_sprites.get_sprites_from_layer(3)
        '''
        #Tag Verified message
        self.tverified = LcarsText(colours.BLUE, (89, 70), "", 1.5)
        all_sprites.add(self.tverified, layer=1)
        
        
        # buttons
        all_sprites.add(LcarsButton(colours.RED_BROWN, (250, 33), "LOGOUT       ", self.logoutHandler),
                        layer=4)

        all_sprites.add(LcarsButton(colours.RED_BROWN, (250, 333), "BACK        ", self.backHandler),
                        layer=4)

        
        
        all_sprites.add(LcarsButton(colours.BEIGE, (33, 333), "UP SOLD      ", self.upsoldHandler),
                        layer=4)
        

        
        all_sprites.add(LcarsButton(colours.BEIGE, (33, 33), "VERIFY       ", self.verifyHandler),
                        layer=4)
        

        '''
        
        all_sprites.add(LcarsButton(colours.PURPLE, (59, 197), "Upload", self.gaugesHandler),
                        layer=4)
        
        all_sprites.add(LcarsButton(colours.PEACH, (107, 398), "WEATHER", self.weatherHandler),
                        layer=4)

        '''

        # gadgets
        #all_sprites.add(LcarsGifImage("assets/gadgets/fwscan.gif", (277, 556), 100), layer=1)
        #self.sensor_gadget = subprocess.Popen("assets/gadgets/scan_uhf.py")
        #self.sensor_gadget = exec(open('python assets/gadgets/scan_uhf.py').read())
        #self.sensor_gadget = os.system("python <path to .py file>")
        #self.sensor_gadget = python assets/gadgets/scan_uhf.py, (235, 150), 100
        #self.sensor_gadget = LcarsGifImage("assets/gadgets/lcars_anim2.gif", (235, 150), 100)
        #self.sensor_gadget.visible = False
        #all_sprites.add(self.sensor_gadget, layer=2)

        '''
        self.dashboard = LcarsImage("assets/gadgets/dashboard.png", (187, 232))
        self.dashboard.visible = False
        all_sprites.add(self.dashboard, layer=2)

        self.weather = LcarsImage("assets/weather.jpg", (188, 122))
        self.weather.visible = False
        all_sprites.add(self.weather, layer=2)
        '''


        #all_sprites.add(LcarsMoveToMouse(colours.WHITE), layer=1)
        self.beep1 = Sound("assets/audio/panel/201.wav")
        Sound("assets/audio/panel/220.wav").play()



        # date display
        self.stardate = LcarsText(colours.BLUE, (208, 143), "DATE 27.11.05 12:02:32", 1.5)
        self.lastClockUpdate = 0
        all_sprites.add(self.stardate, layer=1)


        self.layer1 = all_sprites.get_sprites_from_layer(1)
        self.layer2 = all_sprites.get_sprites_from_layer(2)
        self.layer3 = all_sprites.get_sprites_from_layer(3)
        self.layer4 = all_sprites.get_sprites_from_layer(4)
        self.layer5 = all_sprites.get_sprites_from_layer(5)




    def update(self, screenSurface, fpsClock):
        if pygame.time.get_ticks() - self.lastClockUpdate > 1000:
            #os.system('sudo /home/pi/pydatertc.sh')
            self.stardate.setText("DATE {}".format(datetime.now().strftime("%d.%m.%y %H:%M:%S")))
            self.lastClockUpdate = pygame.time.get_ticks()
        LcarsScreen.update(self, screenSurface, fpsClock)

 
    def limpieza(self):
        for sprite in self.layer0: sprite.visible = True
        for sprite in self.layer1: sprite.visible = False
        for sprite in self.layer2: sprite.visible = False
        for sprite in self.layer3: sprite.visible = False
        for sprite in self.layer4: sprite.visible = False
        for sprite in self.layer5: sprite.visible = True

            


    def handleEvents(self, event, fpsClock):
        if event.type == pygame.MOUSEBUTTONDOWN:
            self.beep1.play()

        if event.type == pygame.MOUSEBUTTONUP:
            return False
    

    def hideInfoText(self):
        if self.info_text[0].visible:
            for sprite in self.info_text:
                sprite.visible = False


    def real_tag_epc(tag):
        string1=tag[14:]
        finalstring =string1[:-6]
        return finalstring

    def readUhf():
        ser = serial.Serial(
            port = '/dev/serial/by-path/platform-3f980000.usb-usb-0:1.2:1.0-port0',
            baudrate = 57600, 
            parity = serial.PARITY_NONE,
            stopbits = serial.STOPBITS_ONE,
            bytesize = serial.EIGHTBITS, 
            timeout = 1 
            )  
        #urlfull(nfctag())

        try:
            tagHex = ""
            ser.write('\x06\xFF\x01\x01\x00\xC6\x8D')     # write a string
            #print(cmdLeer)
            time.sleep(1)
            bytesCola = ser.inWaiting()
            #getserial()
            #print ("serial pi: "+ getserial())
            if bytesCola > 0:
                tagHex = ser.readline(bytesCola).encode('Hex')
                arr = []
                for i in tagHex:
                    arr.append(i)
               
                    fulltag = ''.join(arr)
                    real_tag=real_tag_epc(fulltag)
                    #print "Tag_UHF: "+real_tag
                 
                id_tag_uhf=real_tag
                if tagHex != '0700010101001e4b' and tagHex != '':
                    
                    if len(id_tag_uhf) % 24==0:
                        
                        print ("Lo que se supone a subir: ", id_tag_uhf)
                        '''
                        bien=send_simple_tag_to_api(id_tag_uhf)
                        if bien==1:
                            print "Tag Subido: ", id_tag_uhf
                        else:
                            print "No se subio correctamente o tag repetido: ", id_tag_uhf
                        '''
                           
                else:
                    print("No se encontro ningun tag, codigo no lectura: ",tagHex)
                   
        except:
            print "Super Error General."
            #cursor.close()#Logout Servidor
            sys.exit(0)
            
        #cursor.close() #Logout Servidor



    def upsoldHandler(self, item, event, clock): #laboratorio
        
        def scan_hf():
            try:
                
            	#clf = nfc.ContactlessFrontend("usb")
                clf = nfc.ContactlessFrontend()
                assert clf.open ('usb:072f:2200') is True
                #tag = clf.connect(rdwr={'on-connect': lambda tag: True})
                tag = clf.connect(rdwr={'on-connect': lambda tag: False})
                id_tag_hf = tag.identifier.encode("hex")
                #tag = clf.connect(rdwr={'on-connect': lambda tag: True})

                
                #print(id_tag_hf)
                #print "llego aqui"

                if id_tag_hf!="":
                    #print ("tag nfc: "+ id_tag_hf)
                    #bien=send_db_local(id_tag_hf)
                    assert clf.open ('usb:072f:2200') is False
                    #os.system('sudo /home/pi/pydatertc.sh')

                nfc.ContactlessFrontend.open = nfc_contactlessFronted_open

                
                #os.system('sudo /home/pi/pydatertc.sh')
                
                clf.close()
                
                #id_tag_hf='1231231232' #Lab 3
                #id_tag_hf='1658010e5faab7' #Lab 2 troia
                #id_tag_hf='1658010e5fc1d1' #No se encuentra



            except:
                print "Error scan_hf"
            return id_tag_hf
        

        


    	"""
        ################################################ vender tag con GPRS ################################################
        def scan_hf():
            try:
                '''
                #clf = nfc.ContactlessFrontend("usb")
                clf = nfc.ContactlessFrontend()
                assert clf.open ('usb:072f:2200') is True
                #tag = clf.connect(rdwr={'on-connect': lambda tag: True})
                tag = clf.connect(rdwr={'on-connect': lambda tag: False})
                id_tag_hf = tag.identifier.encode("hex")
                #tag = clf.connect(rdwr={'on-connect': lambda tag: True})

                
                #print(id_tag_hf)
                #print "llego aqui"

                if id_tag_hf!="":
                    #print ("tag nfc: "+ id_tag_hf)
                    #bien=send_db_local(id_tag_hf)
                    assert clf.open ('usb:072f:2200') is False
                    #os.system('sudo /home/pi/pydatertc.sh')

                nfc.ContactlessFrontend.open = nfc_contactlessFronted_open

                
                #os.system('sudo /home/pi/pydatertc.sh')
                
                clf.close()
                '''
                #id_tag_hf='1231231232' #Lab 3
                #id_tag_hf='1658010e5faab7' #Lab 2 troia
                #id_tag_hf='1658010e5faab7' #No se encuentra
                id_tag_hf='1658010e5fd84f' # se encuentra no vendido

                



            except:
                print "Error scan_hf"
            return id_tag_hf
        



        ####################################################################################################################################################
        def upSold(scan_hf):

            ##################################### Escanear Serial ###############################
            def getserial():
                '''
                # Extract serial from cpuinfo file
                cpuserial = "0000000000000000"
                try:
                    f = open('/proc/cpuinfo','r')
                    for line in f:
                      if line[0:6]=='Serial':
                        cpuserial = line[10:26]
                    f.close()
                except:
                    cpuserial = "ERROR000000000"
                '''
                cpuserial = "00000000395pharm"
                return cpuserial
                

            #print scan_hf
            























            ######################################### Subir a la nube con el WIFI ################################
                    
            def send_simple_tag_to_api(url,scan_hf):
                try:
                    #simplemente agregar aqui, el key y el value. y lo pasas por la funcion. ya el api se encarga del resto. 
                    #payload = {'id_tag_nfc':scan_hf,'serial_number':getserial()}
                    payload = {'id_tag_nfc':scan_hf}

                    resp = requests.get(url)
                    print(resp.url)

                    if resp.status_code==200:
                        data=resp.json()
                        tag_found = str(data["tag_found"])
                        sold = str(data["sold"])

                        if tag_found=="1":
                            if sold == "0":
                                #print "Tag encontrado"
                                data = {}
                                data['nfc'] = scan_hf
                                data['name'] = 'PerezTroia Pharmacy'
                                data['feedback'] = 'Tag Sold'
                                data['type'] = '3'
                                data['serial_number'] = '00000000395pharm'

                                params = urllib.urlencode(data)
                                f = urllib.urlopen("http://54.183.201.48/api/make_traceability?%s" % params)
                                self.tverified.setText("Tag Sold by PerezTroia Pharmacy")
                                print scan_hf
                                print "params"+params
                                
                                #echo luis123 | sudo -S nfc-list
                                #os.system('sudo /home/pi/pydatertc.sh')
                                return 1
                            if sold == "1":
                                print "Tag has been sold before, cant be sold again"

                                return 2
                        if tag_found=="0":
                            print "Tag is not in VeriPro Database"
                            return 3

                    else:
                        print ("Error while sending to API. Check url or API.")
                        return -1
                except:
                    print ("General Error while sending to API")
                    return -1
                    
                    
            ######################################### Subir a la nube con el GPRS ################################      
                    
            def send_cloud_GRPS(url):

                GPIO.setmode(GPIO.BCM)
                # Enable Serial Communication
                #port = serial.Serial("/dev/ttyUSB1", baudrate=115200, timeout=5)
                port = serial.Serial("/dev/serial/by-path/platform-3f980000.usb-usb-0:1.5:1.0-port0", baudrate=115200, timeout=5)

                port.flushInput()

                port.write('AT'+'\r\n') 
                rcv = port.read(10)
                time.sleep(0.1)

                port.write('AT+CSQ'+'\r\n') #Signal quality report
                rcv = port.read(10)
                time.sleep(0.1)

                port.write('AT+CGATT=1'+'\r\n') #Attach from GPRS service
                rcv = port.read(10)
                time.sleep(0.1)
                print "1"
                port.write('AT+SAPBR=3,1,"CONTYPE","GPRS"'+'\r\n') #Bearer setting for application based on ip, Type of internet conection ->GPRS
                rcv = port.read(10)
                time.sleep(0.1)

                port.write('AT+SAPBR=3,1,"APN","internet.ideasclaro.com.do"'+'\r\n') #Name of APN
                rcv = port.read(10)
                time.sleep(0.1)
                print "2"
                port.write('AT+SAPBR=1,1'+'\r\n') #Open bearer, bearer is conected 
                rcv = port.read(10)
                time.sleep(0.1)

                port.write('AT+HTTPINIT'+'\r\n') #Initialize HTTP service
                rcv = port.read(10)
                time.sleep(0.1)

                port.write('AT+HTTPPARA="URL","'+url+'"'+'\r\n') #Set HTTP parameters Value
                rcv = port.read(10)
                time.sleep(0.1)
                print "3"
                port.write('AT+HTTPACTION=0'+'\r\n')  #HTTP method action, method ->GET 
                rcv = port.read(10)
                
                time.sleep(3)

                port.write('AT+HTTPREAD'+'\r\n')  #Read HTTP server response 
                rcv = port.read(10)
                time.sleep(0.1)

                port.write('AT+HTTPTERM'+'\r\n') #Terminate HTTP service
                rcv = port.read(1000)
                

                if '"tag_found":"1"' in rcv: 
                    if '"sold":"0"' in rcv:
                        print "el scan_hf", scan_hf


                        print "Tag econtrado y no vendido"
                        '''
                        #print "Tag encontrado"
                        
                        data = {}
                        data['nfc'] = scan_hf
                        data['name'] = 'PerezTroia Pharmacy'
                        data['feedback'] = 'Tag Sold'
                        data['type'] = '3'
                        data['serial_number'] = '00000000395pharm'

                        params = urllib.urlencode(data)
                        f = urllib.urlopen("http://54.183.201.48/api/make_traceability?%s" % params)
                        self.tverified.setText("Tag Sold by PerezTroia Pharmacy")
                        print scan_hf
                        print "params"+params
                        '''

                        
                        #echo luis123 | sudo -S nfc-list
                        #os.system('sudo /home/pi/pydatertc.sh')

                        print rcv
                        return 1
                    elif '"sold":"1"' in rcv: 
                        print "tag encontrado pero vendido"
                        print rcv
                        return 2    
                elif '"tag_found":"0"' in rcv: 
                    print "Tag no encontrado"
                    print rcv
                    return 3
                else:
                    print "Error en el GRPS"
                    print rcv
                    return -1

                

            #url = ("http://54.183.201.48/api/tags?nfc=%s")
            url = "http://54.183.201.48/api/tag_product/"+scan_hf

            for c in xrange(1,2):


                var=send_simple_tag_to_api(url,scan_hf)
                print "el hf: "+ scan_hf
 
                if var == 1:    
                    print "Tag is in VeriPro Database "


                if var == 2:
                    #update_tag(id_tag_nfc)
                    #update_tag(id_tag_uhf)
                    print "Tag is in VeriPro Database but has been sold"

                if var == 3:
                    #update_tag(id_tag_nfc)
                    #update_tag(id_tag_uhf)
                    print "Tag isnt VeriPro Database"

                if var == 0:
                    print "Tag isnt VeriPro Database"
                    
                if var == -1:
                    
                    print "Error de conexion, intentando GPRS"
                    #url="http://54.183.201.48/api/tags?nfc="+scan_hf #posiblemente quitar serial
                    url = "http://54.183.201.48/api/tag_product/"+scan_hf
                    print url

                    var_gprs=send_cloud_GRPS(url)
                    if var_gprs==1:
                        print "Tag is on Database and wasnt sold yet"
                        url2 = "http://54.183.201.48/api/make_traceability?nfc="+scan_hf+"&name=PerezTroia%20Pharmacy&feedback=TagSold&type=3&serial_number=00000000395pharm"
                        send_cloud_GRPS (url2)
                        self.tverified.setText("Tag Sold by PerezTroia Pharmacy")


                    if var_gprs==2:
                        #update_tag(id_tag_uhf)
                        print "Tag is on Database but has been sold"
                        self.tverified.setText("Tag Sold, Can't be sold again!")


                    if var_gprs==0:
                        print "Tag is not in VeriPro Database"
                        self.tverified.setText("Tag is not in VeriPro Database")
                    if var_gprs==-1:
                        print "Error de conexion. Reintentar mas tarde"
                    

            print "FIN."

        upSold(scan_hf())

        """
        

        























        ############ vender tag sin GPRS #################################


        def urlfullsold(scan_hf):

            #url = ("http://54.183.201.48/api/tags?nfc=%s")
            url = "http://54.183.201.48/api/tag_product/"+scan_hf
            print "la url",url


            try:
                data2 = {}
                data2['nfc'] = scan_hf
                #print data
                resp = requests.get(url,params=data2)
                #print resp
                data2=resp.json()
                tag_found = str(data2["tag_found"])
                sold = str(data2["sold"])
                print "el sold ",sold
                print "el tag found", tag_found

                if tag_found == "1":
                    if sold == "0":
                        #print "la vaina e roba"

                        #if sold == "0":

                        data = {}
                        data['nfc'] = scan_hf
                        data['name'] = 'PerezTroia Pharmacy'
                        data['feedback'] = 'Tag Sold'
                        data['type'] = '3'
                        data['serial_number'] = '00000000395pharm'

                        params = urllib.urlencode(data)
                        print "params?"
                        print params
                        f = urllib.urlopen("http://54.183.201.48/api/make_traceability?%s" % params)
                        self.tverified.setText("Tag Has Been Sold by PerezTroia Pharmacy")
                        print scan_hf
                        print "params"+params
                        
                        #echo luis123 | sudo -S nfc-list
                        #os.system('sudo /home/pi/pydatertc.sh')
                        return 1
                    if sold == "1":
                        print "Tag has been sold before, cant sold again"
                        self.tverified.setText("Tag has been sold before, Can't Sold again")

                if tag_found == "0":
                    print "No se encuentra en la Base de datos Veripro"
                    print scan_hf 
                    self.tverified.setText("Tag Couldn't Be Found in VeriPro DataBase")
                    #os.system('sudo /home/pi/pydatertc.sh')
                    #sudo -S nfc-list
                    return 2
                else:
                    print ("Error while sending to API. Check url or API.")
                    return -1


            except:
                print ("General Error while sending to API")
                self.tverified.setText("Tag is not in VeriPro DataBase, Can't Be Sold")
                #os.system('sudo /home/pi/pydatertc.sh')
                return -1
#############################33


            
        urlfullsold(scan_hf())












    def verifyHandler(self, item, event, clock): ######################################## farmacia boton verificar #########################
        


        def scan_hf():
            try:
                
            	#clf = nfc.ContactlessFrontend("usb")
                clf = nfc.ContactlessFrontend()
                assert clf.open ('usb:072f:2200') is True
                #tag = clf.connect(rdwr={'on-connect': lambda tag: True})
                tag = clf.connect(rdwr={'on-connect': lambda tag: False})
                id_tag_hf = tag.identifier.encode("hex")
                #tag = clf.connect(rdwr={'on-connect': lambda tag: True})

                
                #print(id_tag_hf)
                #print "llego aqui"

                if id_tag_hf!="":
                    #print ("tag nfc: "+ id_tag_hf)
                    #bien=send_db_local(id_tag_hf)
                    assert clf.open ('usb:072f:2200') is False
                    #os.system('sudo /home/pi/pydatertc.sh')

                nfc.ContactlessFrontend.open = nfc_contactlessFronted_open

                
                #os.system('sudo /home/pi/pydatertc.sh')
                
                clf.close()
                
                #id_tag_hf='1231231232' #Lab 3
                #id_tag_hf='1658010e5faab7' #Lab 2 troia
                #id_tag_hf='1658010e5faab7' #No se encuentra



            except:
                print "Error scan_hf"
            return id_tag_hf
        

        """
        
        ####################################################################################################################################################
        def uploadVerify(scan_hf):

            ##################################### Escanear Serial ###############################
            def getserial():
                '''
                # Extract serial from cpuinfo file
                cpuserial = "0000000000000000"
                try:
                    f = open('/proc/cpuinfo','r')
                    for line in f:
                      if line[0:6]=='Serial':
                        cpuserial = line[10:26]
                    f.close()
                except:
                    cpuserial = "ERROR000000000"
                '''
                cpuserial = "00000000395pharm"
                return cpuserial
                

            #print scan_hf
            

            ######################################### Subir a la nube con el WIFI ################################
                    
            def send_simple_tag_to_api(url,scan_hf):
                try:
                    #simplemente agregar aqui, el key y el value. y lo pasas por la funcion. ya el api se encarga del resto. 
                    #payload = {'id_tag_nfc':scan_hf,'serial_number':getserial()}
                    payload = {'id_tag_nfc':scan_hf}

                    resp = requests.get(url,params=payload)
                    print(resp.url)

                    if resp.status_code==200:
                        data=resp.json()
                        success = str(data["success"])
                        if success=="1":
                            print "sucesss 1?"
                            return 1
                        if success=="2":
                            print "Ya esta en la nube"
                            return 2
                        if success=="0":
                            print data
                            return 0
                    else:
                        print ("Error while sending to API. Check url or API.")
                        return -1
                except:
                    print ("General Error while sending to API")
                    return -1
                    
                    
            ######################################### Subir a la nube con el GPRS ################################      
                    
            def send_cloud_GRPS(url):
                
                #GPIO.setmode(GPIO.BOARD)
                # Enable Serial Communication
                #port = serial.Serial("/dev/ttyUSB1", baudrate=115200, timeout=5)
                port = serial.Serial("/dev/serial/by-path/platform-3f980000.usb-usb-0:1.5:1.0-port0", baudrate=115200, timeout=5)

                port.flushInput()

                port.write('AT'+'\r\n') 
                rcv = port.read(10)
                time.sleep(0.1)

                port.write('AT+CSQ'+'\r\n') #Signal quality report
                rcv = port.read(10)
                time.sleep(0.1)

                port.write('AT+CGATT=1'+'\r\n') #Attach from GPRS service
                rcv = port.read(10)
                time.sleep(0.1)
                print "1"
                port.write('AT+SAPBR=3,1,"CONTYPE","GPRS"'+'\r\n') #Bearer setting for application based on ip, Type of internet conection ->GPRS
                rcv = port.read(10)
                time.sleep(0.1)

                port.write('AT+SAPBR=3,1,"APN","internet.ideasclaro.com.do"'+'\r\n') #Name of APN
                rcv = port.read(10)
                time.sleep(0.1)
                print "2"
                port.write('AT+SAPBR=1,1'+'\r\n') #Open bearer, bearer is conected 
                rcv = port.read(10)
                time.sleep(0.1)

                port.write('AT+HTTPINIT'+'\r\n') #Initialize HTTP service
                rcv = port.read(10)
                time.sleep(0.1)

                port.write('AT+HTTPPARA="URL","'+url+'"'+'\r\n') #Set HTTP parameters Value
                rcv = port.read(10)
                time.sleep(0.1)
                print "3"
                port.write('AT+HTTPACTION=0'+'\r\n')  #HTTP method action, method ->GET 
                rcv = port.read(10)
                
                time.sleep(3)

                port.write('AT+HTTPREAD'+'\r\n')  #Read HTTP server response 
                rcv = port.read(10)
                time.sleep(0.1)

                port.write('AT+HTTPTERM'+'\r\n') #Terminate HTTP service
                rcv = port.read(1000)
                

                if '"success":"1"' in rcv: 
                    print "Registro EXITOSO"
                    print rcv
                    return 1
                elif '"success":"2"' in rcv: 
                    print "Existe en la BD"
                    print rcv
                    return 2    
                elif '"success":"0"' in rcv: 
                    print "Registro NO EXITOSO"
                    print rcv
                    return 0
                else:
                    print "Error en el GRPS"
                    print rcv
                    return -1
                    
            def update_tag(id_tag_uhf):
                

                try:
                    #sql="UPDATE tags set cloud=1,date_uploaded=now() where id_tag_nfc='%s'"%(id_tag_nfc)
                    sql2="UPDATE tags set cloud=1,date_uploaded=now() where id_tag_uhf='%s'"%(id_tag_uhf)

                    if str(id_tag_uhf)!="":
                        cursor.execute(sql2)
                    
                    con.commit()
                    print "Tag Uploaded: " +str(id_tag_uhf)
                    #print "Tag Uploaded: " +str(id_tag_nfc)
                except:
                    print "Tag subido a la nube pero no a la BD local."
                
            ######################################### MAIN PROGRAM ################################
            #con= ndb.connect ('localhost','root','password','vp')
            #cursor= con.cursor()
            #tag_id_department=1 #department por default
            url = ("http://54.183.201.48/api/tags?nfc=%s")
            #scan_hf() = id_tag_nfc

            #sql="SELECT `id_tag_uhf` FROM `tags` where cloud=0 limit 1"

            #cursor.execute(sql)
            #valores = cursor.fetchall()

            #c=1
            for c in xrange(1,2):
                #c = c-1    
                #id_tag_uhf = row[0]
                #id_tag_nfc = row[0]

                var=send_simple_tag_to_api(url,scan_hf)
                print "el hf: "+ scan_hf
                #var=send_simple_tag_nfc_to_api(url,id_tag_nfc,tag_id_department)
                #aqui estas asisgnando dos valores a una variable. por lo tanto la variable tendra el ultimo valor asignado
                #este es el error que tienes. pero puedes subir los dos tags, por la misma funcion. 
                if var == 1:    
                    print "no esta en la nube"


                if var == 2:
                    #update_tag(id_tag_nfc)
                    #update_tag(id_tag_uhf)
                    print "esta en la nube"

                if var == 0:
                    print "Tag no encontrado"
                    
                if var == -1:
                	
                    print "Error de conexion, intentando GPRS"
                    url="http://54.183.201.48/api/tags?nfc="+scan_hf #posiblemente quitar serial
                    print url

                    
                    print url
                    var_gprs=send_cloud_GRPS(url)
                    if var_gprs==1:
                        print "Tag is on Database"

                    if var_gprs==2:
                        #update_tag(id_tag_uhf)
                        print "Esta en la nube"

                    if var_gprs==0:
                        print "Tag is not in Database"
                    if var_gprs==-1:
                        print "Error de conexion. Reintentar mas tarde"
                    

            print "FIN."
            #cursor.close()#Logout Servidor
            #############################################################################################################33
        
        uploadVerify(scan_hf())
        """
        





        ############################## VERIFICAR TAG SIN GPRS V1.0 NO TOCAR! ##############################
        
        def urlverify(scan_hf, self):
            #url = ("http://54.183.201.48/api/tags?nfc=%s")
            url = "http://54.183.201.48/api/tag_product/"+scan_hf
           

            try:
                data2 = {}
                data2['nfc'] = scan_hf
                #print data
                resp = requests.get(url,params=data2)
                #print resp
                data2=resp.json()
                tag_found = str(data2["tag_found"])
                """
                sold = str(data2["sold"])
                print "el sold ",sold
                print "el tag found", tag_found
                """

                if tag_found == "1":
 
                    print "Se encuentra en la Base de datos Veripro"
                    print scan_hf
                    self.tverified.setText("Tag Has Been Verified Original by Veripro")
                    #echo luis123 | sudo -S nfc-list
                    #os.system('sudo /home/pi/pydatertc.sh')
                    return 1


                if tag_found == "0":
                    print "No se encuentra en la Base de datos Veripro"
                    print scan_hf 
                    self.tverified.setText("Tag Can't Be Verified as Original By VeriPro")
                    #os.system('sudo /home/pi/pydatertc.sh')
                    #sudo -S nfc-list
                    return 2

                else:
                    print ("Error while sending to API. Check url or API.")
                    return -1


            except:
                print ("General Error while sending to API")
                self.tverified.setText("Tag Can't Be Verified as Original By VeriPro")
                #os.system('sudo /home/pi/pydatertc.sh')
                return -1
            

        ##correr scripts tag vendido y verificar tag

        #urlfullsold(scan_hf)  
        urlverify(scan_hf(),self)
        

    def backHandler(self, item, event, clock):
        from screens.screenoption import ScreenOption
        self.loadScreen(ScreenOption())


    def logoutHandler(self, item, event, clock): #laboratorio
        from screens.authorize import ScreenAuthorize
        self.loadScreen(ScreenAuthorize())
        