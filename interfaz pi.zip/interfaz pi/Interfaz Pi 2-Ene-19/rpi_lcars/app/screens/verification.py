#!/usr/bin/env python
# -*- coding: utf-8 -*-

import pygame
from pygame.locals import *

from numpy import array
from numpy import *
import sys, traceback
import MySQLdb as ndb
import random
import serial
import sys
import time
import json
from pprint import pprint
import copy
import os, time
import signal
		
#signal.signal(signal.SIGINT, signal_handler)

class verify:
	def on_execute(self):
		pass

		#########################################Subir a la bd local################################

		def send_db_local(id_tag_uhf):
				try:
					
					
					#sql="INSERT INTO tags (`id_tag_uhf`,date_created,cloud,date_uploaded) VALUES (123213213213213123155588,now(),0,now())"

					sql="INSERT INTO tags (`id_tag_uhf`,date_created,cloud,date_uploaded) VALUES (%s,now(),0,now());"
					args=(id_tag_uhf)
					
					cursor.execute(sql,args)
					con.commit()
					#print "llego aqui."
					return 1
				except:
					return 0
					#print "soy yo?"
				
				
				
		######################################### FILTRAR EPC ################################

		def real_tag_epc(tag):
			string1=tag[14:]
			finalstring =string1[:-6]
			return finalstring

		def getserial():
		  # Extract serial from cpuinfo file
		  cpuserial = "0000000000000000"
		  try:
			f = open('/proc/cpuinfo','r')
			for line in f:
			  if line[0:6]=='Serial':
				cpuserial = line[10:26]
			f.close()
		  except:
			cpuserial = "ERROR000000000"

		  return cpuserial


		ser = serial.Serial(

			port = '/dev/serial/by-path/platform-3f980000.usb-usb-0:1.2:1.0-port0',
			#port = '/dev/ttyUSB0',
			baudrate = 57600, 
			parity = serial.PARITY_NONE,
			stopbits = serial.STOPBITS_ONE,
			bytesize = serial.EIGHTBITS, 
			timeout = 1 
			)  
		con= ndb.connect ('localhost','root','password','vp')
		cursor= con.cursor() 
			
		while 1:
			try:
				#print("serial: ", getserial())
				#print('port open is: ', ser.name)         # check which port was really used
				tagHex = ""
				ser.write('\x06\xFF\x01\x01\x00\xC6\x8D')     # write a string
				#print(cmdLeer)
				time.sleep(1)
				bytesCola = ser.inWaiting()
				#getserial()
				#print ("serial pi: "+ getserial())
				if bytesCola > 0:
					tagHex = ser.readline(bytesCola).encode('Hex')
					arr = []
					for i in tagHex:
						arr.append(i)
			
					fulltag = ''.join(arr)
					real_tag=real_tag_epc(fulltag)
					#print "Tag_UHF: "+real_tag
				
				id_tag_uhf=real_tag
				if tagHex != '0700010101001e4b' and tagHex != '':
					
					if len(id_tag_uhf) % 24==0:
						
						#print ("Lo que se supone a subir: ", id_tag_uhf)
						bien=send_db_local(id_tag_uhf)
						if bien==1:
							print "Tag Subido: ", id_tag_uhf
						else:
							print "No se subio correctamente o tag repetido: ", id_tag_uhf
							
						
				else:
					print("No se encontro ningun tag, codigo no lectura: ",tagHex)
					
			except:
				print "se jodio la mielda."
				cursor.close()#Logout Servidor
				sys.exit(0)
		 
		cursor.close() #Logout Servidor
		
		pass
		
if __name__ == "__main__":
	theApp = verify()
	theApp.on_execute()

