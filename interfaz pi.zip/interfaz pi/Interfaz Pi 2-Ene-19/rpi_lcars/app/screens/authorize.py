import pygame
from pygame.mixer import Sound
import os, time
import serial
import RPi.GPIO as GPIO  

from ui import colours
from ui.widgets.background import LcarsBackgroundImage
from ui.widgets.gifimage import LcarsGifImage
from ui.widgets.lcars_widgets import LcarsText
from ui.widgets.screen import LcarsScreen
from ui.widgets.lcars_widgets import LcarsButton



class ScreenAuthorize(LcarsScreen):

    def setup(self, all_sprites):


        all_sprites.add(LcarsBackgroundImage("assets/blackbackground.png"),
                        layer=0)
       # all_sprites.add(LcarsBackgroundImage("assets/lcars_screen_2.png"),
                       # layer=0)
		 # all_sprites.add(LcarsBackgroundImage("assets/lcars_screen_2.png"),
                       # layer=0)



        all_sprites.add(LcarsGifImage("assets/gadgets/loguitoB.gif", (0, 185), 50), 
                        layer=0)        

        all_sprites.add(LcarsText(colours.ORANGE, (126, 159), "AUTHORIZATION REQUIRED", 1.3),
                        layer=0)

        
        all_sprites.add(LcarsText(colours.BLUE, (162, 130), "By Veripro. Touch to Proceed", 1.5),
                        layer=1)
                        
        '''

        all_sprites.add(LcarsText(colours.BLUE, (211, 164), "Access Denied", 1.5),
                        layer=3)
        '''
        
        
        all_sprites.add(LcarsText(colours.REAL_RED, (207, 100), "FAILED ATTEMPTS WILL BE REPORTED", 1.5),layer=3)


        all_sprites.add(LcarsButton(colours.GREY_BLUE, (164, 125), "1", self.num_1), layer=2)
        all_sprites.add(LcarsButton(colours.GREY_BLUE, (212, 125), "2", self.num_2), layer=2)
        all_sprites.add(LcarsButton(colours.GREY_BLUE, (164, 255), "3", self.num_3), layer=2)
        all_sprites.add(LcarsButton(colours.GREY_BLUE, (212, 255), "4", self.num_4), layer=2)
        #all_sprites.add(LcarsButton(colours.GREY_BLUE, (320, 410), "5", self.num_5), layer=2)
        #all_sprites.add(LcarsButton(colours.GREY_BLUE, (370, 410), "6", self.num_6), layer=2)
        #all_sprites.add(LcarsButton(colours.GREY_BLUE, (320, 550), "7", self.num_7), layer=2)
        #all_sprites.add(LcarsButton(colours.GREY_BLUE, (370, 550), "8", self.num_8), layer=2)

        self.layer1 = all_sprites.get_sprites_from_layer(1)
        self.layer2 = all_sprites.get_sprites_from_layer(2)
        self.layer3 = all_sprites.get_sprites_from_layer(3)


        # sounds
        Sound("assets/audio/panel/215.wav").play()
        self.sound_granted = Sound("assets/audio/accessing.wav")
        self.sound_beep1 = Sound("assets/audio/panel/201.wav")
        self.sound_denied = Sound("assets/audio/access_denied.wav")
        self.sound_deny1 = Sound("assets/audio/deny_1.wav")
        self.sound_deny2 = Sound("assets/audio/deny_2.wav")

        ############
        # SET PIN CODE WITH THIS VARIABLE
        ############
        self.pin = 1
        ############
        self.reset()

    def reset(self):
        # Variables for PIN code verification
        self.correct = 0
        self.pin_i = 0
        self.granted = False
        for sprite in self.layer1: sprite.visible = True
        for sprite in self.layer2: sprite.visible = False
        for sprite in self.layer3: sprite.visible = True

    def handleEvents(self, event, fpsClock):
        if event.type == pygame.MOUSEBUTTONDOWN:
            # Play sound
            self.sound_beep1.play()

        if event.type == pygame.MOUSEBUTTONUP:
            if (not self.layer2[0].visible):
                for sprite in self.layer1: sprite.visible = False
                for sprite in self.layer2: sprite.visible = True
                for sprite in self.layer3: sprite.visible = False

                Sound("assets/audio/enter_authorization_code.wav").play()
            elif (self.pin_i == len(str(self.pin))):
                # Ran out of button presses
                if (self.correct == 1):
                    self.sound_granted.play()
                    from screens.screenoption import ScreenOption
                    self.loadScreen(ScreenOption())

                    #from screens.main import ScreenMain
                    #self.loadScreen(ScreenMain())
                else:
                    self.sound_deny2.play()
                    self.sound_denied.play()
                    #all_sprites.add(LcarsText(colours.RED, (130, 156), "Access Denied", 1),layer=1)
                    for sprite in self.layer3: sprite.visible = True
                    self.reset()


                    

        return False

    def num_1(self, item, event, clock):
        if str(self.pin)[self.pin_i] == '1':
            self.correct += 1

        self.pin_i += 1

    def num_2(self, item, event, clock):
        if str(self.pin)[self.pin_i] == '2':
            self.correct += 1

        self.pin_i += 1

    def num_3(self, item, event, clock):
        if str(self.pin)[self.pin_i] == '3':
            self.correct += 1

        self.pin_i += 1

    def num_4(self, item, event, clock):
        if str(self.pin)[self.pin_i] == '4':
            self.correct += 1

        self.pin_i += 1



    def prenderGPRS():
        #!/usr/bin/python
        port = serial.Serial("/dev/serial/by-path/platform-3f980000.usb-usb-0:1.5:1.0-port0", baudrate=115200, timeout=5)

        port.write('AT'+'\r\n') 
        rcv = port.read(10)
        time.sleep(1)

        if "OK" in rcv: 
            print "GPRS esta encendido."
            
        else:

            GPIO.setmode(GPIO.BCM)
            GPIO.setup(12, GPIO.OUT, initial=GPIO.LOW)

            GPIO.output(12, False)
            time.sleep(1)
            GPIO.output(12, True)
            time.sleep(2)
            GPIO.output(12, False)
            time.sleep(3)
            GPIO.cleanup() #this ensures a clean exit

    def conectarGPRS(): 
        # Enable Serial Communication
        #port = serial.Serial("/dev/ttyUSB1", baudrate=115200, timeout=5)
        port = serial.Serial("/dev/serial/by-path/platform-3f980000.usb-usb-0:1.5:1.0-port0", baudrate=115200, timeout=5)

        port.flushInput()

        port.write('AT+CGATT=1'+'\r\n') #Attach from GPRS service
        time.sleep(1)
    
        port.write('AT+SAPBR=3,1,"CONTYPE","GPRS"'+'\r\n') #Bearer setting for application based on ip, Type of internet conection ->GPRS
        time.sleep(1)

        port.write('AT+SAPBR=3,1,"APN","internet.ideasclaro.com.do"'+'\r\n') #Name of APN
        time.sleep(1)
        
        port.write('AT+SAPBR=1,1'+'\r\n') #Open bearer, bearer is conected 
        time.sleep(1)

        print port.read(200)


    #prenderGPRS()
    #time.sleep(5)
    #conectarGPRS()

    '''

    def num_5(self, item, event, clock):
        if str(self.pin)[self.pin_i] == '5':
            self.correct += 1

        self.pin_i += 1

    def num_6(self, item, event, clock):
        if str(self.pin)[self.pin_i] == '6':
            self.correct += 1

        self.pin_i += 1

    def num_7(self, item, event, clock):
        if str(self.pin)[self.pin_i] == '7':
            self.correct += 1

        self.pin_i += 1

    def num_8(self, item, event, clock):
        if str(self.pin)[self.pin_i] == '8':
            self.correct += 1

        self.pin_i += 1

    '''
