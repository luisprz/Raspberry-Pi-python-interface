#!/usr/bin/env python
# -*- coding: utf-8 -*-

from numpy import array
from numpy import *
import sys, traceback
import MySQLdb as ndb
import random
import serial
import sys
import json
from pprint import pprint
import copy
import os, time
import signal
import requests
import serial
import RPi.GPIO as GPIO  
from urllib2 import urlopen
import urllib 
import nfc
from threading import Timer

from datetime import datetime
import pygame
from pygame.mixer import Sound
import subprocess

from ui import colours
from ui.widgets.background import LcarsBackgroundImage, LcarsImage
from ui.widgets.gifimage import LcarsGifImage
from ui.widgets.lcars_widgets import *
from ui.widgets.screen import LcarsScreen
from ui.widgets.sprite import LcarsMoveToMouse

#from datasources.network import get_ip_address_string

FPS = 30 # frames per second to update the screen

class ScreenLab(LcarsScreen):
	global FPSCLOCK
	
	globalverify = False

	def setup(self, all_sprites):

		

		all_sprites.add(LcarsBackgroundImage("assets/blackbackground.png"),
						layer=0)
		
		# panel text
		'''
		all_sprites.add(LcarsText(colours.BLACK, (15, 44), "LCARS 105"),
						layer=1)

		all_sprites.add(LcarsText(colours.BLUE, (21, 179), "VERIPRO", 3),
						layer=1)
		'''
		all_sprites.add(LcarsText(colours.BLUE, (120, 42), "Laboratory by VP System", 3),
						layer=1)
		'''
		all_sprites.add(LcarsBlockMedium(colours.RED_BROWN, (145, 16), "LIGHTS"),
						layer=1)
		all_sprites.add(LcarsBlockSmall(colours.ORANGE, (211, 16), "CAMERAS"),
						layer=1)
		all_sprites.add(LcarsBlockLarge(colours.BEIGE, (249, 16), "ENERGY"),
						layer=1)

		self.ip_address = LcarsText(colours.BLACK, (444, 520),
									get_ip_address_string())
		all_sprites.add(self.ip_address, layer=1)
		'''

		'''
		# info text
		all_sprites.add(LcarsText(colours.WHITE, (192, 174), "EVENT LOG:", 1.5),
						layer=3)
		all_sprites.add(LcarsText(colours.BLUE, (244, 174), "2 ALARM ZONES TRIGGERED", 1.5),
						layer=3)
		all_sprites.add(LcarsText(colours.BLUE, (286, 174), "14.3 kWh USED YESTERDAY", 1.5),
						layer=3)
		all_sprites.add(LcarsText(colours.BLUE, (330, 174), "1.3 Tb DATA USED THIS MONTH", 1.5),
						layer=3)
		self.info_text = all_sprites.get_sprites_from_layer(3)

		'''

		# date display
		
		self.stardate = LcarsText(colours.BLUE, (208, 143), "DATE 27.11.05 12:02:32", 1.5)
		self.lastClockUpdate = 0
		all_sprites.add(self.stardate, layer=1)
		'''

		self.stardate2 = LcarsText(colours.BLUE, (112, 72), "DATE 27.11.05 12:02:32", 1.5)
		self.lastClockhandletime = 0
		all_sprites.add(self.stardate2, layer=1)
		'''
		
		self.tbox = LcarsText(colours.BLUE, (84, 143), "", 1.5)
		all_sprites.add(self.tbox, layer=1)

		# buttons
		all_sprites.add(LcarsButton(colours.RED_BROWN, (250, 33), "LOGOUT       ", self.logoutHandler),
						layer=4)

		all_sprites.add(LcarsButton(colours.RED_BROWN, (250, 333), "BACK        ", self.backHandler),
						layer=4)

		
		all_sprites.add(LcarsButton(colours.BEIGE, (33, 333), "UP ALL       ", self.upallHandler),
						layer=4)
		

		
		all_sprites.add(LcarsButton(colours.BEIGE, (33, 33), "DISPATCH     ", self.dispatchHandler),
						layer=4)
		

		'''
		
		all_sprites.add(LcarsButton(colours.PURPLE, (59, 197), "Upload", self.gaugesHandler),
						layer=4)
		
		all_sprites.add(LcarsButton(colours.PEACH, (107, 398), "WEATHER", self.weatherHandler),
						layer=4)

		'''

		# gadgets
		#all_sprites.add(LcarsGifImage("assets/gadgets/fwscan.gif", (277, 556), 100), layer=1)
		#self.sensor_gadget = subprocess.Popen("assets/gadgets/scan_uhf.py")
		#self.sensor_gadget = exec(open('python assets/gadgets/scan_uhf.py').read())
		#self.sensor_gadget = os.system("python <path to .py file>")
		#self.sensor_gadget = python assets/gadgets/scan_uhf.py, (235, 150), 100
		#self.sensor_gadget = LcarsGifImage("assets/gadgets/lcars_anim2.gif", (235, 150), 100)
		#self.sensor_gadget.visible = False
		#all_sprites.add(self.sensor_gadget, layer=2)

		'''
		self.dashboard = LcarsImage("assets/gadgets/dashboard.png", (187, 232))
		self.dashboard.visible = False
		all_sprites.add(self.dashboard, layer=2)

		self.weather = LcarsImage("assets/weather.jpg", (188, 122))
		self.weather.visible = False
		all_sprites.add(self.weather, layer=2)
		'''
		'''
		self.tverified = LcarsText(colours.BLUE, (154, 147), "", 1.5)
		all_sprites.add(self.tverified, layer=1)
		'''

		#all_sprites.add(LcarsMoveToMouse(colours.WHITE), layer=1)
		self.beep1 = Sound("assets/audio/panel/201.wav")
		Sound("assets/audio/panel/220.wav").play()

		

	def update(self, screenSurface, fpsClock):
		
		if pygame.time.get_ticks() - self.lastClockUpdate > 1000:
			self.stardate.setText("DATE {}".format(datetime.now().strftime("%d.%m.%y %H:%M:%S")))
			self.lastClockUpdate = pygame.time.get_ticks()
		LcarsScreen.update(self, screenSurface, fpsClock)
		

	def handletime(self, screenSurface, fpsClock):
		if pygame.time.get_ticks() - self.lastClockhandletime > 1000:
			self.stardate2.setText("DATE {}".format(datetime.now().strftime("%d.%m.%y %H:%M:%S")))
			self.lastClockhandletime = pygame.time.get_ticks()
		LcarsScreen.handletime(self, screenSurface, fpsClock)


	def handleEvents(self, event, fpsClock):
		if event.type == pygame.MOUSEBUTTONDOWN:
			self.beep1.play()

		if event.type == pygame.MOUSEBUTTONUP:
			return False
	

	def hideInfoText(self):
		if self.info_text[0].visible:
			for sprite in self.info_text:
				sprite.visible = False

	def gaugesHandler(self, item, event, clock): #
		self.hideInfoText()
		self.sensor_gadget.visible = False
		self.dashboard.visible = True
		self.weather.visible = False

	def dispatchHandler(self, item, event, clock): ###################### BOTON despacho #################
		#self.tbox.setText("Dispatching")



		def uhfscan():

			def real_tag_epc(tag):
				string1=tag[14:]
				finalstring =string1[:-6]
				return finalstring

			def getserial():
				# Extract serial from cpuinfo file
				cpuserial = "0000000000000000"
				try:
					f = open('/proc/cpuinfo','r')
					for line in f:
						if line[0:6]=='Serial':
							cpuserial = line[10:26]
					f.close()
				except:
					cpuserial = "ERROR000000000"

				return cpuserial


			ser = serial.Serial(

				port = '/dev/serial/by-path/platform-3f980000.usb-usb-0:1.2:1.0-port0',
				#port = '/dev/ttyUSB0',
				baudrate = 57600, 
				parity = serial.PARITY_NONE,
				stopbits = serial.STOPBITS_ONE,
				bytesize = serial.EIGHTBITS, 
				timeout = 1 
				)  

			c=1
			while c>0:
				try:
					c = c-1
					#print("serial: ", getserial())
					#print('port open is: ', ser.name)         # check which port was really used
					tagHex = ""
					ser.write('\x06\xFF\x01\x01\x00\xC6\x8D')     # write a string
					#print(cmdLeer)
					time.sleep(0.1)
					bytesCola = ser.inWaiting()
					#getserial()
					#print ("serial pi: "+ getserial())
					if bytesCola > 0:
						tagHex = ser.readline(bytesCola).encode('Hex')
						arr = []
						for i in tagHex:
							arr.append(i)
				
						fulltag = ''.join(arr)
						real_tag=real_tag_epc(fulltag)
						#print "Tag_UHF: "+real_tag
					
					id_tag_uhf=real_tag
					if tagHex != '0700010101001e4b' and tagHex != '':
						
						if len(id_tag_uhf) % 24==0:
							#self.tbox.setText("Select an Option")
							#print "Tag_UHF: "+id_tag_uhf

							return id_tag_uhf
								
					else:
						print("No se encontro ningun tag, codigo no lectura: ",tagHex)
						#self.tbox.setText("Nothing to Dispatch")	

				except:
					print "super error general."

		
		def urlfulldispa(uhfscan):			
			url = ("http://54.183.201.48/api/tags?uhf=%s")

			try:
				#self.tbox.setText("Dispatching")
				if uhfscan != None:
			
					data2 = {}
					#print "hay uhfscan:", uhfscan
					data2['uhf'] = uhfscan

					resp = requests.get(url,params=data2)
					data2 = resp.json()
					success = str(data2["success"])

					if success=="1":

						data = {}
						data['uhf'] = uhfscan
						print "el tag: "+uhfscan
						data['name'] = 'Dispatch'
						data['feedback'] = 'Product ready for dispatch'
						data['type'] = '2'
						data['serial_number'] = '00000000395dispa'


						#print "llego asca"
						params = urllib.urlencode(data)
						print params
						
						f = urllib.urlopen("http://54.183.201.48/api/make_traceability?%s" % params)
						#self.tverified.setText("Tag Dispatched by PerezTroia Laboratory")
						#print "uhfscanklk"+uhfscan()
						return 1

					if success=="0":

						print "No se encuentra en la Base de datos Veripro"
						#self.tbox.setText("Tag is not in VeriPro DataBase")
						#print "uhfscanklk"+uhfscan()
						#self.tverified.setText("Tag is not in VeriPro DataBase")
						#os.system('sudo /home/pi/pydatertc.sh')
						#sudo -S nfc-list
						return 2

					else:
						print ("Error while sending to API. Check url or API.")
						return -1
				else: 
					print "Nothing to Dispatch"
					#self.tbox.setText("Nothing to Dispatch")

			except:
				print ("General Error while sending to API")
				#os.system('sudo /home/pi/pydatertc.sh')
				return -1


		#start = time.clock()
		
		for c in xrange(1,50):
			#time.sleep(1)
			urlfulldispa(uhfscan())
	



	def upallHandler(self, item, event, clock): ################################# BOTON subir todo a la bd local y a la nube ###############
				##################################### Escanear Serial ###############################



		def getserial():
			print "llego1"

			# Extract serial from cpuinfo file
			cpuserial = "0000000000000000"
			try:
				f = open('/proc/cpuinfo','r')
				for line in f:
					if line[0:6]=='Serial':
						cpuserial = line[10:26]
				f.close()
			except:
				cpuserial = "ERROR000000000"
			return cpuserial



			##################### A BD local con HF #################
		'''
		def hfscan():
			try:
				#clf = nfc.ContactlessFrontend("usb")
				clf = nfc.ContactlessFrontend()
				assert clf.open ('usb:072f:2200') is True
				#tag = clf.connect(rdwr={'on-connect': lambda tag: True})
				tag = clf.connect(rdwr={'on-connect': lambda tag: False})
				id_tag_hf = tag.identifier.encode("hex")
				#tag = clf.connect(rdwr={'on-connect': lambda tag: True})

				
				print(id_tag_hf)
				print "llego aqui"

				if id_tag_hf!="":
					print ("tag nfc: "+ id_tag_hf)
					#bien=send_db_local(id_tag_hf)
					assert clf.open ('usb:072f:2200') is False
					#os.system('sudo /home/pi/pydatertc.sh')

				nfc.ContactlessFrontend.open = nfc_contactlessFronted_open
				#id_tag_hf='1231231232' #Lab 3
				#id_tag_hf='1658010e5faab7' #Lab 2 troia
				#id_tag_hf='1658010e5faab8' #No se encuentra
				#os.system('sudo /home/pi/pydatertc.sh')
				clf.close()

			except:
				print "Error scan_hf"
			return id_tag_hf


		#hfscan()
		'''


		def uhfscan():


			#signal.signal(signal.SIGINT, signal_handler)


			#########################################Subir a la bd local################################

			def send_db_local(id_tag_uhf):
				try:                 
					#sql="INSERT INTO tags (`id_tag_uhf`,date_created,cloud,date_uploaded) VALUES (123213213213213123155588,now(),0,now())"

					sql="INSERT INTO tags (`id_tag_uhf`,date_created,cloud,date_uploaded) VALUES (%s,now(),0,now());"
					args=(id_tag_uhf)
					
					cursor.execute(sql,args)
					con.commit()
					#print "llego aqui."
					return 1
				except:
					return 0
					#print "soy yo?"
				
				
					
			######################################### FILTRAR EPC ################################

			def real_tag_epc(tag):
				string1=tag[14:]
				finalstring =string1[:-6]
				return finalstring

			def getserial():
				# Extract serial from cpuinfo file
				cpuserial = "0000000000000000"
				try:
					f = open('/proc/cpuinfo','r')
					for line in f:
						if line[0:6]=='Serial':
							cpuserial = line[10:26]
					f.close()
				except:
					cpuserial = "ERROR000000000"

				return cpuserial


			ser = serial.Serial(

				port = '/dev/serial/by-path/platform-3f980000.usb-usb-0:1.2:1.0-port0',
				#port = '/dev/ttyUSB0',
				baudrate = 57600, 
				parity = serial.PARITY_NONE,
				stopbits = serial.STOPBITS_ONE,
				bytesize = serial.EIGHTBITS, 
				timeout = 1 
				)  
			con= ndb.connect ('localhost','root','password','vp')
			cursor= con.cursor() 
				
			
			try:
				#print("serial: ", getserial())
				#print('port open is: ', ser.name)         # check which port was really used
				tagHex = ""
				ser.write('\x06\xFF\x01\x01\x00\xC6\x8D')     # write a string
				#print(cmdLeer)
				time.sleep(0.1)
				bytesCola = ser.inWaiting()
				#getserial()
				#print ("serial pi: "+ getserial())
				if bytesCola > 0:
					tagHex = ser.readline(bytesCola).encode('Hex')
					arr = []
					for i in tagHex:
						arr.append(i)
			
					fulltag = ''.join(arr)
					real_tag=real_tag_epc(fulltag)
					#print "Tag_UHF: "+real_tag
				
				id_tag_uhf=real_tag
				if tagHex != '0700010101001e4b' and tagHex != '':
					
					if len(id_tag_uhf) % 24==0:
						
						#print ("Lo que se supone a subir: ", id_tag_uhf)
						bien=send_db_local(id_tag_uhf)
						if bien==1:
							print "Tag Subido: ", id_tag_uhf
						else:
							print "No se subio correctamente o tag repetido: ", id_tag_uhf
							
						
				else:
					print("No se encontro ningun tag, codigo no lectura: ",tagHex)
					
			except:
				print "se jodio la mielda."
				cursor.close()#Logout Servidor
				sys.exit(0)
			 
			cursor.close() #Logout Servidor

		#uhfscan()

		'''
		def upload(): #Upload

			##################################### Escanear Serial ###############################
			def getserial():
			  # Extract serial from cpuinfo file
			  cpuserial = "0000000000000000"
			  try:
				f = open('/proc/cpuinfo','r')
				for line in f:
				  if line[0:6]=='Serial':
					cpuserial = line[10:26]
				f.close()
			  except:
				cpuserial = "ERROR000000000"

			  return cpuserial


			######################################### Subir a la nube con el WIFI ################################
					
			def send_simple_tag_to_api(url,id_tag_nfc,id_tag_uhf,tag_id_department):
				try:
					#simplemente agregar aqui, el key y el value. y lo pasas por la funcion. ya el api se encarga del resto. 
					payload = {'tag_id_department':tag_id_department,'id_tag_uhf':id_tag_uhf,'id_tag_nfc':id_tag_nfc,'serial_number':getserial()}
					resp = requests.get(url,params=payload)
					print(resp.url)
					if resp.status_code==200:
						data=resp.json()
						success = str(data["success"])
						if success=="1":
							return 1
						if success=="2":
							print "Ya esta en la nube"
							return 2
						if success=="0":
							print data
							return 0
					else:
						print ("Error while sending to API. Check url or API.")
						return -1
				except:
					print ("General Error while sending to API")
					return -1
					
					
			######################################### Subir a la nube con el GPRS ################################  

			def prenderGPRS():
				#!/usr/bin/python
				port = serial.Serial("/dev/serial/by-path/platform-3f980000.usb-usb-0:1.5:1.0-port0", baudrate=115200, timeout=5)

				port.write('AT'+'\r\n') 
				rcv = port.read(10)
				time.sleep(1)

				if "OK" in rcv: 
					print "GPRS esta encendido."
					
				else:

					GPIO.setmode(GPIO.BCM)
					GPIO.setup(12, GPIO.OUT)

					GPIO.output(12, False)
					time.sleep(1)
					GPIO.output(12, True)
					time.sleep(2)
					GPIO.output(12, False)
					time.sleep(3)
					GPIO.cleanup() #this ensures a clean exit



			#prenderGPRS()


					
			def send_cloud_GRPS(url):
				
				GPIO.setmode(GPIO.BOARD)
				# Enable Serial Communication
				port = serial.Serial("/dev/serial/by-path/platform-3f980000.usb-usb-0:1.5:1.0-port0", baudrate=115200, timeout=5)

				port.write('AT'+'\r\n') 
				rcv = port.read(10)
				time.sleep(1)

				port.write('AT+CSQ'+'\r\n') #Signal quality report
				rcv = port.read(10)
				time.sleep(1)

				port.write('AT+CGATT=1'+'\r\n') #Attach from GPRS service
				rcv = port.read(10)
				time.sleep(1)
				print "1"
				port.write('AT+SAPBR=3,1,"CONTYPE","GPRS"'+'\r\n') #Bearer setting for application based on ip, Type of internet conection ->GPRS
				rcv = port.read(10)
				time.sleep(1)

				port.write('AT+SAPBR=3,1,"APN","internet.ideasclaro.com.do"'+'\r\n') #Name of APN
				rcv = port.read(10)
				time.sleep(1)
				print "2"
				port.write('AT+SAPBR=1,1'+'\r\n') #Open bearer, bearer is conected 
				rcv = port.read(10)
				time.sleep(1)

				port.write('AT+HTTPINIT'+'\r\n') #Initialize HTTP service
				rcv = port.read(10)
				time.sleep(1)

				port.write('AT+HTTPPARA="URL","'+url+'"'+'\r\n') #Set HTTP parameters Value
				rcv = port.read(10)
				time.sleep(1)
				print "3"
				port.write('AT+HTTPACTION=0'+'\r\n')  #HTTP method action, method ->GET 
				rcv = port.read(10)
				
				time.sleep(3)

				port.write('AT+HTTPREAD'+'\r\n')  #Read HTTP server response 
				rcv = port.read(10)
				time.sleep(1)

				port.write('AT+HTTPTERM'+'\r\n') #Terminate HTTP service
				rcv = port.read(1000)
				

				if '"success":"1"' in rcv: 
					print "Registro EXITOSO"
					print rcv
					return 1
				elif '"success":"2"' in rcv: 
					print "Existe en la BD"
					print rcv
					return 2    
				elif '"success":"0"' in rcv: 
					print "Registro NO EXITOSO"
					print rcv
					return 0
				else:
					print "Error en el GRPS"
					print rcv
					return -1
					
			def update_tag(id_tag_nfc,id_tag_uhf):
				

				try:
					sql="UPDATE tags set cloud=1,date_uploaded=now() where id_tag_nfc='%s'"%(id_tag_nfc)
					sql2="UPDATE tags set cloud=1,date_uploaded=now() where id_tag_uhf='%s'"%(id_tag_uhf)
					if str(id_tag_nfc)!="":
						cursor.execute(sql)
					if str(id_tag_uhf)!="":
						cursor.execute(sql2)
					
					con.commit()
					print "Tag Uploaded: " +str(id_tag_uhf)
					print "Tag Uploaded: " +str(id_tag_nfc)
				except:
					print "Tag subido a la nube pero no a la BD local."
				
			######################################### MAIN PROGRAM ################################
			con= ndb.connect ('localhost','root','password','vp')
			cursor= con.cursor()
			tag_id_department=1 #department por default
			url="http://54.183.201.48/api/tags_save"

			sql="SELECT `id_tag_nfc`,`id_tag_uhf` FROM `tags` where cloud=0 limit 1"

			cursor.execute(sql)
			valores = cursor.fetchall()

			for row in valores:
				id_tag_uhf = row[1]
				id_tag_nfc = row[0]

				var=send_simple_tag_to_api(url,id_tag_nfc,id_tag_uhf,tag_id_department)
				#var=send_simple_tag_nfc_to_api(url,id_tag_nfc,tag_id_department)
				#aqui estas asisgnando dos valores a una variable. por lo tanto la variable tendra el ultimo valor asignado
				#este es el error que tienes. pero puedes subir los dos tags, por la misma funcion. 
				if var==1 or var ==2:
					#update_tag(id_tag_nfc)
					update_tag(id_tag_nfc,id_tag_uhf)
				
				if var==0:
					print "Datos en la nube"
					
				if var==-1:
					print "Error de conexion, intentando GPRS"
					url=url+ "?tag_id_department=" +str(tag_id_department)+"&id_tag_nfc="+str(id_tag_nfc)+"&id_tag_uhf="+str(id_tag_uhf)+"&serial_number="+str(getserial())

					print url
					var_gprs=send_cloud_GRPS(url)
					if var_gprs==1 or var_gprs==2:
						update_tag(id_tag_uhf,id_tag_uhf)
						

					if var_gprs==0:
						print "Datos en la nube"
					if var_gprs==-1:
						print "Error de conexion. Reintentar mas tarde"

			print "FIN."
			cursor.close()#Logout Servidor
		'''
		def upload():           ################################################################### UPLOAD NUEVO #############################

			##################################### Escanear Serial ###############################
			def getserial():
			  # Extract serial from cpuinfo file
			  cpuserial = "0000000000000000"
			  try:
			    f = open('/proc/cpuinfo','r')
			    for line in f:
			      if line[0:6]=='Serial':
			        cpuserial = line[10:26]
			    f.close()
			  except:
			    cpuserial = "ERROR000000000"

			  return cpuserial


			######################################### Subir a la nube con el WIFI ################################
			        
			def send_simple_tag_to_api(url,id_tag_uhf,tag_id_department):
				try:
					#simplemente agregar aqui, el key y el value. y lo pasas por la funcion. ya el api se encarga del resto. 
					payload = {'tag_id_department':tag_id_department,'id_tag_uhf':id_tag_uhf,'serial_number':getserial()}
					resp = requests.get(url,params=payload)
					print(resp.url)
					if resp.status_code==200:
						data=resp.json()
						success = str(data["success"])
						if success=="1":
							return 1
						if success=="2":
							print "Ya esta en la nube"
							return 2
						if success=="0":
							print data
							return 0
					else:
						print ("Error while sending to API. Check url or API.")
						return -1
				except:
					print ("General Error while sending to API")
					return -1
					
					
			######################################### Subir a la nube con el GPRS ################################	

			def prenderGPRS():
			    #!/usr/bin/python
			    port = serial.Serial("/dev/serial/by-path/platform-3f980000.usb-usb-0:1.5:1.0-port0", baudrate=115200, timeout=5)

			    print "verificando si gprs esta encendido..."
			    port.write('AT'+'\r\n') 
			    rcv = port.read(10)
			    time.sleep(1)

			    if "OK" in rcv: 
			        print "GPRS esta encendido."
			        
			    else:

			    	print "encendiendo gprs.."

			        GPIO.setmode(GPIO.BCM)
			        GPIO.setup(12, GPIO.OUT, initial=GPIO.LOW)

			        GPIO.output(12, False)
			        time.sleep(1)
			        GPIO.output(12, True)
			        time.sleep(2)
			        GPIO.output(12, False)
			        time.sleep(3)
			        GPIO.cleanup() #this ensures a clean exit
			        time.sleep(10)

			        print "gprs encendido!"


			def conectarGPRS():	
				# Enable Serial Communication
				#port = serial.Serial("/dev/ttyUSB1", baudrate=115200, timeout=5)
				port = serial.Serial("/dev/serial/by-path/platform-3f980000.usb-usb-0:1.5:1.0-port0", baudrate=115200, timeout=5)
				
				port.flushInput()

				port.write('AT+SAPBR=2,1'+'\r\n') #Initialize HTTP service
				time.sleep(1)
				rcv = port.read(50)

				if '0.0.0.0' in rcv:

					print "conectando gprs a internet..."
					port.write('AT+CGATT=1'+'\r\n') #Attach from GPRS service
					time.sleep(1)

					port.write('AT+SAPBR=3,1,"CONTYPE","GPRS"'+'\r\n') #Bearer setting for application based on ip, Type of internet conection ->GPRS
					time.sleep(1)

					port.write('AT+SAPBR=3,1,"APN","internet.ideasclaro.com.do"'+'\r\n') #Name of APN
					time.sleep(1)

					port.write('AT+SAPBR=1,1'+'\r\n') #Open bearer, bearer is conected 
					time.sleep(1)

					print port.read(200)

				else:
					"El gprs ya esta conectado a internet!"

				print "gprs conectado!"




			'''
			prenderGPRS()
			time.sleep(10)
			conectarGPRS()

			while True:
				send_cloud_GRPS('http://54.183.201.48/api/tags?nfc=1')
			'''


			def send_cloud_GRPS(url2):

				port = serial.Serial("/dev/serial/by-path/platform-3f980000.usb-usb-0:1.5:1.0-port0", baudrate=115200, timeout=5)
				
				port.flushInput()

				port.write('AT+SAPBR=2,1'+'\r\n') #Initialize HTTP service
				rcv = port.read(10)
				time.sleep(1)

				if '0.0.0.0' in rcv: 
					print "conectando GPRS"
					conectarGPRS()
					print "GPRS conectado!"

				port.write('AT+HTTPINIT'+'\r\n') #Initialize HTTP service
				time.sleep(1)

				port.write('AT+HTTPPARA="URL","'+url2+'"'+'\r\n') #Set HTTP parameters Value
				time.sleep(1)

				port.write('AT+HTTPACTION=0'+'\r\n')  #HTTP method action, method ->GET 
				time.sleep(3)

				#port.flushInput()

				port.write('AT+HTTPREAD'+'\r\n')  #Read HTTP server response 
				time.sleep(1)

				rcv = port.read(200)

				port.write('AT+HTTPTERM'+'\r\n') #Terminate HTTP service
				time.sleep(1)

				print "imprimiendo rcv"
				print rcv
				print url2
				

				if 'success:"1"' in rcv: 
					print "Registro EXITOSO"
					print rcv
					return 1
				if 'success:2' in rcv: 
					print "Existe en la BD"
					print rcv
					return 2	
				if 'success:0' in rcv: 
					print "Registro NO EXITOSO"
					print rcv
					return 0

				if 'id_tag_uhf:"The id tag uhf field is required when id tag nfc is ."':
					print "Tag vacio en BD local"
					print rcv
					return 5

				
				else:
					print "Error en el GRPS"
					print rcv
					return -1
					
			def update_tag(id_tag_uhf):
				

				try:
					#sql="UPDATE tags set cloud=1,date_uploaded=now() where id_tag_nfc='%s'"%(id_tag_nfc)
					sql2="UPDATE tags set cloud=1,date_uploaded=now() where id_tag_uhf='%s'"%(id_tag_uhf)

					if str(id_tag_uhf)!="":
						cursor.execute(sql2)
					
					con.commit()
					print "Tag Uploaded: " +str(id_tag_uhf)
					#print "Tag Uploaded: " +str(id_tag_nfc)
				except:
					print "Tag subido a la nube pero no a la BD local."
				
			######################################### MAIN PROGRAM ################################
			con= ndb.connect ('localhost','root','password','vp')
			cursor= con.cursor()
			tag_id_department=1 #department por default
			url="http://54.183.201.48/api/tags_save"


			sql="SELECT `id_tag_uhf` FROM `tags` where cloud=0 limit 1"

			cursor.execute(sql)
			valores = cursor.fetchall()

			for row in valores:
				id_tag_uhf = row[0]
				#id_tag_nfc = row[0]

				var=send_simple_tag_to_api(url,id_tag_uhf,tag_id_department)
				#var=send_simple_tag_nfc_to_api(url,id_tag_nfc,tag_id_department)
				#aqui estas asisgnando dos valores a una variable. por lo tanto la variable tendra el ultimo valor asignado
				#este es el error que tienes. pero puedes subir los dos tags, por la misma funcion. 
				if var==1 or var ==2:
					#update_tag(id_tag_nfc)
					update_tag(id_tag_uhf)
				
				if var==0:
					print "Datos en la nube"
					
				if var==-1:
					print "Error de conexion, intentando GPRS"
					prenderGPRS()
					conectarGPRS()

					#url2=url+ "?tag_id_department=" +str(tag_id_department)+"&id_tag_uhf="+str(id_tag_uhf)+"&serial_number="+str(getserial())
					url2 = "http://54.183.201.48/api/tags_save?tag_id_department=1&id_tag_uhf="+id_tag_uhf+"&serial_number=000000003952c83b"

					print "imprimiendo la url: "
					print url2
					var_gprs=send_cloud_GRPS(url2)
					if var_gprs==1:
						update_tag(id_tag_uhf)

					if var_gprs==2:
						update_tag(id_tag_uhf)
					
					if var_gprs==5:
						print "ta vacio"

					

					if var_gprs==0:
						print "Datos en la nube"
					if var_gprs==-1:
						print "Error de conexion. Reintentar mas tarde"

			print "FIN."
			cursor.close()#Logout Servidor




		for c in xrange(1,10):
			#self.tbox.setText("Dispatching")
			upload()
			for c in xrange (1,10):
				uhfscan()
			

	
	def logoutHandler(self, item, event, clock):
		from screens.authorize import ScreenAuthorize
		self.loadScreen(ScreenAuthorize())
	
	def backHandler(self, item, event, clock):
		from screens.screenoption import ScreenOption
		self.loadScreen(ScreenOption())
		
	
