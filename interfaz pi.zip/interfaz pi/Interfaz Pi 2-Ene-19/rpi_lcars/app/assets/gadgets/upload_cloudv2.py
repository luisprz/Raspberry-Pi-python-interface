#!/usr/bin/env python
import sys, traceback
import os, time
import MySQLdb as ndb
import json
import requests
import serial
import RPi.GPIO as GPIO  

##################################### Escanear Serial ###############################
def getserial():
  # Extract serial from cpuinfo file
  cpuserial = "0000000000000000"
  try:
    f = open('/proc/cpuinfo','r')
    for line in f:
      if line[0:6]=='Serial':
        cpuserial = line[10:26]
    f.close()
  except:
    cpuserial = "ERROR000000000"

  return cpuserial


######################################### Subir a la nube con el WIFI ################################
        
def send_simple_tag_to_api(url,id_tag_nfc,id_tag_uhf,tag_id_department):
	try:
		#simplemente agregar aqui, el key y el value. y lo pasas por la funcion. ya el api se encarga del resto. 
		payload = {'tag_id_department':tag_id_department,'id_tag_uhf':id_tag_uhf,'id_tag_nfc':id_tag_nfc,'serial_number':getserial()}
		resp = requests.get(url,params=payload)
		print(resp.url)
		if resp.status_code==200:
			data=resp.json()
			success = str(data["success"])
			if success=="1":
				return 1
			if success=="2":
				print "Ya esta en la nube"
				return 2
			if success=="0":
				print data
				return 0
		else:
			print ("Error while sending to API. Check url or API.")
			return -1
	except:
		print ("General Error while sending to API")
		return -1
		
		
######################################### Subir a la nube con el GPRS ################################		
		
def send_cloud_GRPS(url):
	
	GPIO.setmode(GPIO.BOARD)
	# Enable Serial Communication
	port = serial.Serial("/dev/ttyUSB1", baudrate=115200, timeout=5)

	port.write('AT'+'\r\n') 
	rcv = port.read(10)
	time.sleep(1)

	port.write('AT+CSQ'+'\r\n') #Signal quality report
	rcv = port.read(10)
	time.sleep(1)

	port.write('AT+CGATT=1'+'\r\n') #Attach from GPRS service
	rcv = port.read(10)
	time.sleep(1)
	print "1"
	port.write('AT+SAPBR=3,1,"CONTYPE","GPRS"'+'\r\n') #Bearer setting for application based on ip, Type of internet conection ->GPRS
	rcv = port.read(10)
	time.sleep(1)

	port.write('AT+SAPBR=3,1,"APN","internet.ideasclaro.com.do"'+'\r\n') #Name of APN
	rcv = port.read(10)
	time.sleep(1)
	print "2"
	port.write('AT+SAPBR=1,1'+'\r\n') #Open bearer, bearer is conected 
	rcv = port.read(10)
	time.sleep(1)

	port.write('AT+HTTPINIT'+'\r\n') #Initialize HTTP service
	rcv = port.read(10)
	time.sleep(1)

	port.write('AT+HTTPPARA="URL","'+url+'"'+'\r\n') #Set HTTP parameters Value
	rcv = port.read(10)
	time.sleep(1)
	print "3"
	port.write('AT+HTTPACTION=0'+'\r\n')  #HTTP method action, method ->GET 
	rcv = port.read(10)
	
	time.sleep(3)

	port.write('AT+HTTPREAD'+'\r\n')  #Read HTTP server response 
	rcv = port.read(10)
	time.sleep(1)

	port.write('AT+HTTPTERM'+'\r\n') #Terminate HTTP service
	rcv = port.read(1000)
	

	if '"success":"1"' in rcv: 
		print "Registro EXITOSO"
		print rcv
		return 1
	elif '"success":"2"' in rcv: 
		print "Existe en la BD"
		print rcv
		return 2	
	elif '"success":"0"' in rcv: 
		print "Registro NO EXITOSO"
		print rcv
		return 0
	else:
		print "Error en el GRPS"
		print rcv
		return -1
		
def update_tag(id_tag_nfc,id_tag_uhf):
	

	try:
		sql="UPDATE tags set cloud=1,date_uploaded=now() where id_tag_nfc='%s'"%(id_tag_nfc)
		sql2="UPDATE tags set cloud=1,date_uploaded=now() where id_tag_uhf='%s'"%(id_tag_uhf)
		if str(id_tag_nfc)!="":
			cursor.execute(sql)
		if str(id_tag_uhf)!="":
			cursor.execute(sql2)
		
		con.commit()
		print "Tag Uploaded: " +str(id_tag_uhf)
		print "Tag Uploaded: " +str(id_tag_nfc)
	except:
		print "Tag subido a la nube pero no a la BD local."
	
######################################### MAIN PROGRAM ################################
con= ndb.connect ('localhost','root','password','vp')
cursor= con.cursor()
tag_id_department=1 #department por default
url="http://54.183.201.48/api/tags_save"

sql="SELECT `id_tag_nfc`,`id_tag_uhf` FROM `tags` where cloud=0 limit 1"

cursor.execute(sql)
valores = cursor.fetchall()

for row in valores:
	id_tag_uhf = row[1]
	id_tag_nfc = row[0]

	var=send_simple_tag_to_api(url,id_tag_nfc,id_tag_uhf,tag_id_department)
	#var=send_simple_tag_nfc_to_api(url,id_tag_nfc,tag_id_department)
	#aqui estas asisgnando dos valores a una variable. por lo tanto la variable tendra el ultimo valor asignado
	#este es el error que tienes. pero puedes subir los dos tags, por la misma funcion. 
	if var==1 or var ==2:
		#update_tag(id_tag_nfc)
		update_tag(id_tag_nfc,id_tag_uhf)
	
	if var==0:
		print "Datos en la nube"
		
	if var==-1:
		print "Error de conexion, intentando GPRS"
		url=url+ "?tag_id_department=" +str(tag_id_department)+"&id_tag_nfc="+str(id_tag_nfc)+"&id_tag_uhf="+str(id_tag_uhf)+"&serial_number="+str(getserial())

		print url
		var_gprs=send_cloud_GRPS(url)
		if var_gprs==1 or var_gprs==2:
			update_tag(id_tag_uhf,id_tag_uhf)
			

		if var_gprs==0:
			print "Datos en la nube"
		if var_gprs==-1:
			print "Error de conexion. Reintentar mas tarde"

print "FIN."
cursor.close()#Logout Servidor
