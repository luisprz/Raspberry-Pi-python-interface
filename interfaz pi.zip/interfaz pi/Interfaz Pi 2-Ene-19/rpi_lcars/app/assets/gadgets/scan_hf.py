#!/usr/bin/env python
# -*- coding: utf-8 -*-


import nfc
import requests
from numpy import array
from numpy import *
import sys, traceback
import MySQLdb as ndb
import random
import serial
import sys
import time
import json
from pprint import pprint
import copy
import os, time
import signal
		
#signal.signal(signal.SIGINT, signal_handler)
clf = nfc.ContactlessFrontend("usb")


def send_db_local(id_tag_hf):
		try:
			
			sql="INSERT INTO tags (`id_tag_nfc`,date_created,cloud,date_uploaded) VALUES ('%s',now(),0,now());"%(id_tag_hf)
			
			#print sql
			cursor.execute(sql)
			con.commit()
			#print "llego aqui."
			return 1
		except:
			return 0
			print "soy yo?"
		
        

def getserial():
  # Extract serial from cpuinfo file
  cpuserial = "0000000000000000"
  try:
    f = open('/proc/cpuinfo','r')
    for line in f:
      if line[0:6]=='Serial':
        cpuserial = line[10:26]
    f.close()
  except:
    cpuserial = "ERROR000000000"

  return cpuserial
  
def scan_hf():
	try:
		tag = clf.connect(rdwr={'on-connect': lambda tag: False})
		id_tag_hf = tag.identifier.encode("hex")
		#print(id_tag_hf)
	except:
		print "Error scan_hf"
	return id_tag_hf
	


con= ndb.connect ('localhost','root','password','vp')
cursor= con.cursor() 
	
while 1:
	try:

		#time.sleep(1)
		id_tag_hf = 0
		id_tag_hf = scan_hf()


		#id_tag_hf2 = scan_hf()
		#id_tag_hf = id_tag_hf2
		
		if id_tag_hf!="":

			print ("Lo que se supone va subir: "+ id_tag_hf)
			bien=send_db_local(id_tag_hf)
			tag = clf.connect(rdwr={'on-connect': lambda tag: True}) #QUE HACE ESTO


		if bien==1:
			print "Tag Subido: ", id_tag_hf
			id_tag_hf = 0	


			
		else:
			print "No se subio correctamente o tag repetido: ", id_tag_hf					
				
		
			
			
	except:
		print "Error General."
		cursor.close()#Logout Servidor
		sys.exit(0)
 
cursor.close() #Logout Servidor

