from screens.authorize import ScreenAuthorize
from ui.ui import UserInterface

# global config
UI_PLACEMENT_MODE = True
RESOLUTION = (480, 320)
FPS = 60
DEV_MODE = True

if __name__ == "__main__":
    firstScreen = ScreenAuthorize()
    ui = UserInterface(firstScreen, RESOLUTION, UI_PLACEMENT_MODE, FPS, DEV_MODE)
    #pygame.display.set_mode(flags = pygame.NOFRAME)



    while (True):
        ui.tick()
