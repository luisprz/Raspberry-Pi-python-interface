#!/usr/bin/env python
# -*- coding: utf-8 -*-

from numpy import array
from numpy import *
import sys, traceback
import MySQLdb as ndb
import random
import serial
import sys
import json
from pprint import pprint
import copy
import os, time
import signal
import requests
import serial
import RPi.GPIO as GPIO  
from urllib2 import urlopen
import urllib 
import nfc


from datetime import datetime
import pygame
from pygame.mixer import Sound
import subprocess

from ui import colours
from ui.widgets.background import LcarsBackgroundImage, LcarsImage
from ui.widgets.gifimage import LcarsGifImage
from ui.widgets.lcars_widgets import *
from ui.widgets.screen import LcarsScreen
from ui.widgets.sprite import LcarsMoveToMouse

#from datasources.network import get_ip_address_string
#signal.signal(signal.SIGINT, signal_handler)

tag_id_department=1 #department por default


class ScreenPharm(LcarsScreen):
    def setup(self, all_sprites):
        
        all_sprites.add(LcarsBackgroundImage("assets/blackbackground.png"),
                        layer=0)


        # panel text
        '''
        all_sprites.add(LcarsText(colours.WHITE, (15, 44), "LCARS 105"),
                        layer=1)
        '''
        all_sprites.add(LcarsText(colours.ORANGE, (16, 145), "VeriPro", 2),
                        layer=1)


        
        

        '''
        all_sprites.add(LcarsBlockLarge(colours.WHITE, (103, 334), "KLK"),
                        layer=1)
        '''
        

        '''
        self.ip_address = LcarsText(colours.BLACK, (444, 520), get_ip_address_string())
        all_sprites.add(self.ip_address, layer=1)
        '''
        

        '''
        # info text
        all_sprites.add(LcarsText(colours.WHITE, (192, 174), "EVENT LOG:", 1.5),
                        layer=3)
        all_sprites.add(LcarsText(colours.BLUE, (244, 174), "2 ALARM ZONES TRIGGERED", 1.5),
                        layer=3)
        all_sprites.add(LcarsText(colours.BLUE, (286, 174), "14.3 kWh USED YESTERDAY", 1.5),
                        layer=3)
        all_sprites.add(LcarsText(colours.BLUE, (330, 174), "1.3 Tb DATA USED THIS MONTH", 1.5),
                        layer=3)
        self.info_text = all_sprites.get_sprites_from_layer(3)
        '''
        #Tag Verified message
        self.tverified = LcarsText(colours.BLUE, (154, 147), "", 1.5)
        all_sprites.add(self.tverified, layer=1)
        
        
        # buttons
        all_sprites.add(LcarsButton(colours.RED_BROWN, (234, 167), "LOGOUT", self.logoutHandler),
                        layer=4)

        
        
        all_sprites.add(LcarsButton(colours.BEIGE, (62, 193), "UpSold", self.upsoldHandler),
                        layer=4)
        

        
        all_sprites.add(LcarsButton(colours.BEIGE, (62, 60), "Verify", self.verifyHandler),
                        layer=4)
        

        '''
        
        all_sprites.add(LcarsButton(colours.PURPLE, (59, 197), "Upload", self.gaugesHandler),
                        layer=4)
        
        all_sprites.add(LcarsButton(colours.PEACH, (107, 398), "WEATHER", self.weatherHandler),
                        layer=4)

        '''

        # gadgets
        #all_sprites.add(LcarsGifImage("assets/gadgets/fwscan.gif", (277, 556), 100), layer=1)
        #self.sensor_gadget = subprocess.Popen("assets/gadgets/scan_uhf.py")
        #self.sensor_gadget = exec(open('python assets/gadgets/scan_uhf.py').read())
        #self.sensor_gadget = os.system("python <path to .py file>")
        #self.sensor_gadget = python assets/gadgets/scan_uhf.py, (235, 150), 100
        #self.sensor_gadget = LcarsGifImage("assets/gadgets/lcars_anim2.gif", (235, 150), 100)
        #self.sensor_gadget.visible = False
        #all_sprites.add(self.sensor_gadget, layer=2)

        '''
        self.dashboard = LcarsImage("assets/gadgets/dashboard.png", (187, 232))
        self.dashboard.visible = False
        all_sprites.add(self.dashboard, layer=2)

        self.weather = LcarsImage("assets/weather.jpg", (188, 122))
        self.weather.visible = False
        all_sprites.add(self.weather, layer=2)
        '''


        #all_sprites.add(LcarsMoveToMouse(colours.WHITE), layer=1)
        self.beep1 = Sound("assets/audio/panel/201.wav")
        Sound("assets/audio/panel/220.wav").play()



        # date display
        self.stardate = LcarsText(colours.BLUE, (112, 72), "DATE 27.11.05 12:02:32", 1.5)
        self.lastClockUpdate = 0
        all_sprites.add(self.stardate, layer=1)


        self.layer1 = all_sprites.get_sprites_from_layer(1)
        self.layer2 = all_sprites.get_sprites_from_layer(2)
        self.layer3 = all_sprites.get_sprites_from_layer(3)
        self.layer4 = all_sprites.get_sprites_from_layer(4)
        self.layer5 = all_sprites.get_sprites_from_layer(5)




    def update(self, screenSurface, fpsClock):
        if pygame.time.get_ticks() - self.lastClockUpdate > 2000:
            #os.system('sudo /home/pi/pydatertc.sh')
            self.stardate.setText("DATE {}".format(datetime.now().strftime("%d.%m.%y %H:%M:%S")))
            self.lastClockUpdate = pygame.time.get_ticks()
        LcarsScreen.update(self, screenSurface, fpsClock)

 
    def limpieza(self):
        for sprite in self.layer0: sprite.visible = True
        for sprite in self.layer1: sprite.visible = False
        for sprite in self.layer2: sprite.visible = False
        for sprite in self.layer3: sprite.visible = False
        for sprite in self.layer4: sprite.visible = False
        for sprite in self.layer5: sprite.visible = True

            


    def handleEvents(self, event, fpsClock):
        if event.type == pygame.MOUSEBUTTONDOWN:
            self.beep1.play()

        if event.type == pygame.MOUSEBUTTONUP:
            return False
    

    def hideInfoText(self):
        if self.info_text[0].visible:
            for sprite in self.info_text:
                sprite.visible = False


    def real_tag_epc(tag):
        string1=tag[14:]
        finalstring =string1[:-6]
        return finalstring

    def readUhf():
        ser = serial.Serial(
            port = '/dev/serial/by-path/platform-3f980000.usb-usb-0:1.2:1.0-port0',
            baudrate = 57600, 
            parity = serial.PARITY_NONE,
            stopbits = serial.STOPBITS_ONE,
            bytesize = serial.EIGHTBITS, 
            timeout = 1 
            )  
        #urlfull(nfctag())

        try:
            tagHex = ""
            ser.write('\x06\xFF\x01\x01\x00\xC6\x8D')     # write a string
            #print(cmdLeer)
            time.sleep(1)
            bytesCola = ser.inWaiting()
            #getserial()
            #print ("serial pi: "+ getserial())
            if bytesCola > 0:
                tagHex = ser.readline(bytesCola).encode('Hex')
                arr = []
                for i in tagHex:
                    arr.append(i)
               
                    fulltag = ''.join(arr)
                    real_tag=real_tag_epc(fulltag)
                    #print "Tag_UHF: "+real_tag
                 
                id_tag_uhf=real_tag
                if tagHex != '0700010101001e4b' and tagHex != '':
                    
                    if len(id_tag_uhf) % 24==0:
                        
                        print ("Lo que se supone a subir: ", id_tag_uhf)
                        '''
                        bien=send_simple_tag_to_api(id_tag_uhf)
                        if bien==1:
                            print "Tag Subido: ", id_tag_uhf
                        else:
                            print "No se subio correctamente o tag repetido: ", id_tag_uhf
                        '''
                           
                else:
                    print("No se encontro ningun tag, codigo no lectura: ",tagHex)
                   
        except:
            print "Super Error General."
            #cursor.close()#Logout Servidor
            sys.exit(0)
            
        #cursor.close() #Logout Servidor


    def logoutHandler(self, item, event, clock): #laboratorio
        from screens.authorize import ScreenAuthorize
        self.loadScreen(ScreenAuthorize())
    

    def upsoldHandler(self, item, event, clock): #laboratorio
        
        

        def scan_hf():
            try:
                #clf = nfc.ContactlessFrontend("usb")
                clf = nfc.ContactlessFrontend()
                assert clf.open ('usb:072f:2200') is True
                #tag = clf.connect(rdwr={'on-connect': lambda tag: True})
                tag = clf.connect(rdwr={'on-connect': lambda tag: False})
                id_tag_hf = tag.identifier.encode("hex")
                #tag = clf.connect(rdwr={'on-connect': lambda tag: True})

                
                print(id_tag_hf)
                print "llego aqui"

                if id_tag_hf!="":
                    print ("tag nfc: "+ id_tag_hf)
                    #bien=send_db_local(id_tag_hf)
                    assert clf.open ('usb:072f:2200') is False
                    #os.system('sudo /home/pi/pydatertc.sh')

                nfc.ContactlessFrontend.open = nfc_contactlessFronted_open
                #id_tag_hf='1231231232' #Lab 3
                #id_tag_hf='1658010e5faab7' #Lab 2 troia
                #id_tag_hf='1658010e5faab8' #No se encuentra
                #os.system('sudo /home/pi/pydatertc.sh')
                clf.close()

            except:
                print "Error scan_hf"
            return id_tag_hf


        def urlfullsold(nfctag):

            url = ("http://54.183.201.48/api/tags?nfc=%s")

            try:
                data2 = {}
                data2['nfc'] = nfctag()
                #print data
                resp = requests.get(url,params=data2)
                #print resp
                data2=resp.json()
                success = str(data2["success"])
                if success=="1":

                    data = {}
                    data['nfc'] = nfctag()
                    data['name'] = 'PerezTroia Pharmacy'
                    data['feedback'] = 'Tag Sold'
                    data['type'] = '3'
                    data['serial_number'] = '00000000395pharm'

                    params = urllib.urlencode(data)
                    f = urllib.urlopen("http://54.183.201.48/api/make_traceability?%s" % params)
                    self.tverified.setText("Tag Sold by PerezTroia Pharmacy")
                    print nfctag()
                    
                    #echo luis123 | sudo -S nfc-list
                    #os.system('sudo /home/pi/pydatertc.sh')
                    return 1
                if success=="0":
                    print "No se encuentra en la Base de datos Veripro"
                    print nfctag() 
                    self.tverified.setText("Tag is not in VeriPro DataBase")
                    #os.system('sudo /home/pi/pydatertc.sh')
                    #sudo -S nfc-list
                    return 2
                else:
                    print ("Error while sending to API. Check url or API.")
                    return -1


            except:
                print ("General Error while sending to API")
                #os.system('sudo /home/pi/pydatertc.sh')
                return -1
#############################33


            
        urlfullsold(scan_hf)

    def verifyHandler(self, item, event, clock): #farmacia
        


        def scan_hf():
            try:
            	#clf = nfc.ContactlessFrontend("usb")
                clf = nfc.ContactlessFrontend()
                assert clf.open ('usb:072f:2200') is True
                #tag = clf.connect(rdwr={'on-connect': lambda tag: True})
                tag = clf.connect(rdwr={'on-connect': lambda tag: False})
                id_tag_hf = tag.identifier.encode("hex")
                #tag = clf.connect(rdwr={'on-connect': lambda tag: True})

                
                print(id_tag_hf)
                print "llego aqui"

                if id_tag_hf!="":
                    print ("tag nfc: "+ id_tag_hf)
                    #bien=send_db_local(id_tag_hf)
                    assert clf.open ('usb:072f:2200') is False
                    #os.system('sudo /home/pi/pydatertc.sh')

                nfc.ContactlessFrontend.open = nfc_contactlessFronted_open
                #id_tag_hf='1231231232' #Lab 3
                #id_tag_hf='1658010e5faab7' #Lab 2 troia
                #id_tag_hf='1658010e5faab8' #No se encuentra
                #os.system('sudo /home/pi/pydatertc.sh')
                clf.close()



            except:
                print "Error scan_hf"
            return id_tag_hf





        def urlverify(nfctag, self):
            url = ("http://54.183.201.48/api/tags?nfc=%s")

            try:
                data = {}
                data['nfc'] = nfctag()
                #print data
                resp = requests.get(url,params=data)
                #print resp
                data=resp.json()
                success = str(data["success"])
                if success=="1":
                    print "Se encuentra en la Base de datos Veripro"
                    print nfctag()
                    self.tverified.setText("Verified by Veripro")
                    #echo luis123 | sudo -S nfc-list
                    #os.system('sudo /home/pi/pydatertc.sh')
                    return 1
                if success=="0":
                    print "No se encuentra en la Base de datos Veripro"
                    print nfctag() 
                    self.tverified.setText("Tag is not in VeriPro DataBase")
                    #os.system('sudo /home/pi/pydatertc.sh')
                    #sudo -S nfc-list
                    return 2
                else:
                    print ("Error while sending to API. Check url or API.")
                    return -1


            except:
                print ("General Error while sending to API")
                #os.system('sudo /home/pi/pydatertc.sh')
                return -1

        ##correr scripts tag vendido y verificar tag

        #urlfullsold(scan_hf)  
        urlverify(scan_hf,self)

